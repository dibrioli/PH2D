| pincel | célula | papel | lei | veredicto |
|---|---|---|---|---|
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N1 | padrao | pigmento | furos 63.70 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N1 | liso | pigmento | furos 63.70 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 27.40; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 27.40; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 18.50; km_max_plano 25.80; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N1 | liso | velha | km_p99_plano 18.50; km_max_plano 25.80; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 17.20; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N3 | liso | velha | km_p99_plano 17.20; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 9; degraus_x_plano 7 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 9; degraus_x_plano 7 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 23.90; km_max_plano 49.00; degraus_y_plano 9; degraus_x_plano 12 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.90; km_max_plano 49.00; degraus_y_plano 9; degraus_x_plano 12 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 20.60; km_max_plano 32.70; degraus_y_plano 13; degraus_x_plano 5 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 32.90; degraus_y_plano 13; degraus_x_plano 5 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 50.00; degraus_y_plano 10; degraus_x_plano 4 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 48.80; degraus_y_plano 10; degraus_x_plano 4 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 19.20; km_max_plano 26.50; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 19.20; km_max_plano 26.50; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N1 | padrao | velha | furos 100.00; degraus_y_plano 7; degraus_x_plano 14 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N1 | padrao | pigmento | furos 82.06 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N1 | liso | velha | furos 100.00; degraus_y_plano 7; degraus_x_plano 14 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N1 | liso | pigmento | furos 83.15 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N3 | padrao | velha | km_p99_plano 27.40; km_max_plano 39.10; degraus_y_plano 11; degraus_x_plano 6 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N3 | liso | velha | km_p99_plano 27.30; km_max_plano 39.10; degraus_y_plano 11; degraus_x_plano 6 |
| Oil/Flat/Thick Impasto | P40/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N1 | padrao | velha | km_p99_plano 24.80; km_max_plano 44.20; degraus_y_plano 9; degraus_x_plano 11 |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N1 | liso | velha | km_p99_plano 24.90; km_max_plano 43.20; degraus_y_plano 9; degraus_x_plano 11 |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 21.50; km_max_plano 33.00; degraus_y_plano 13 |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 32.60; degraus_y_plano 13 |
| Oil/Flat/Thick Impasto | P40/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N1 | padrao | pigmento | furos 63.70 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N1 | liso | pigmento | furos 63.70 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 27.40; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 27.40; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 18.50; km_max_plano 25.80; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N1 | liso | velha | km_p99_plano 18.50; km_max_plano 25.80; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 17.20; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N3 | liso | velha | km_p99_plano 17.20; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 12; degraus_x_plano 11 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 98.57; degraus_y_plano 2 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 11; degraus_x_plano 11 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 98.57; degraus_y_plano 2 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 34.20; km_max_plano 36.50; furos 12.42; degraus_y_plano 10; degraus_x_plano 16 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 34.20; km_max_plano 36.50; furos 12.42; degraus_y_plano 10; degraus_x_plano 16 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.2/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 24.00; km_max_plano 49.40; degraus_y_plano 9; degraus_x_plano 47 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 24.00; km_max_plano 49.40; degraus_y_plano 9; degraus_x_plano 46 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 19.60; km_max_plano 28.00; degraus_y_plano 13; degraus_x_plano 35 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 19.60; km_max_plano 28.00; degraus_y_plano 13; degraus_x_plano 35 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 22.90; km_max_plano 62.20; degraus_y_plano 10; degraus_x_plano 33 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 22.90; km_max_plano 61.70; degraus_y_plano 10; degraus_x_plano 33 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 7; degraus_x_plano 31 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 7; degraus_x_plano 30 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N3 | padrao | velha | km_p99_plano 33.70; km_max_plano 37.30; furos 67.73; degraus_y_plano 9; degraus_x_plano 8 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N3 | padrao | pigmento | furos 21.15 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N3 | liso | velha | km_p99_plano 33.70; km_max_plano 37.30; furos 67.73; degraus_y_plano 9; degraus_x_plano 8 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.2/N3 | liso | pigmento | furos 21.15 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 22.50; km_max_plano 51.10; degraus_y_plano 9; degraus_x_plano 11 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 22.50; km_max_plano 51.10; degraus_y_plano 9; degraus_x_plano 11 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 30.60; degraus_y_plano 13; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 19.70; km_max_plano 29.90; degraus_y_plano 13; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 21.00; km_max_plano 52.40; degraus_y_plano 11; degraus_x_plano 5 |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N1 | liso | velha | km_p99_plano 21.00; km_max_plano 52.40; degraus_y_plano 11; degraus_x_plano 5 |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.00; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.00; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N1 | padrao | pigmento | furos 63.70 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N1 | liso | pigmento | furos 63.70 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 27.40; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 27.40; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 18.50; km_max_plano 25.80; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 18.50; km_max_plano 25.80; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 17.20; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 17.20; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N1 | padrao | pigmento | furos 72.42; degraus_y_plano 1 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 3 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 72.42; degraus_y_plano 1 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 23.90; km_max_plano 29.00; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 23.90; km_max_plano 29.00; degraus_y_plano 9 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.2/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 11 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 24.10; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 24.10; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 18.50; km_max_plano 24.90; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 18.50; km_max_plano 24.90; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 17.80; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 17.80; km_max_plano 26.70; degraus_y_plano 8 |
| Oil/Flat/Thick Impasto | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 10; degraus_x_plano 18 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 99.61; degraus_y_plano 2 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 10; degraus_x_plano 18 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N1 | liso | pigmento | furos 99.61; degraus_y_plano 2 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N3 | padrao | velha | km_p99_plano 29.90; km_max_plano 36.70; furos 29.27; degraus_y_plano 12; degraus_x_plano 14 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 0.03 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N3 | liso | velha | km_p99_plano 29.90; km_max_plano 36.70; furos 29.30; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.2/N3 | liso | pigmento | furos 0.03 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 23.00; km_max_plano 51.60; degraus_y_plano 11; degraus_x_plano 40 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 23.00; km_max_plano 51.60; degraus_y_plano 11; degraus_x_plano 40 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 19.20; km_max_plano 26.80; degraus_y_plano 11; degraus_x_plano 4 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 19.20; km_max_plano 26.70; degraus_y_plano 11; degraus_x_plano 4 |
| Oil/Flat/Thick Impasto | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 22.50; km_max_plano 58.00; degraus_y_plano 10; degraus_x_plano 16 |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 22.50; km_max_plano 58.00; degraus_y_plano 10; degraus_x_plano 16 |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.20; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.20; degraus_y_plano 10 |
| Oil/Flat/Thick Impasto | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N3 | padrao | velha | manchas_azul_plano 4.43; km_p99_plano 23.40; km_max_plano 24.40; degraus_y_plano 3; degraus_x_plano 19 |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N3 | liso | velha | degraus_y_plano 4; degraus_x_plano 86 |
| Oil/Knife/Knife Stain | P40/W0/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0/pr1/N1 | padrao | velha | manchas_azul_plano 4.75; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 64 |
| Oil/Knife/Knife Stain | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P40/W0/pr1/N1 | liso | velha | km_p99_plano 24.60; km_max_plano 26.90; degraus_y_plano 12; degraus_x_plano 153 |
| Oil/Knife/Knife Stain | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 25.40; degraus_y_plano 11; degraus_x_plano 41 |
| Oil/Knife/Knife Stain | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P40/W0/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.20; degraus_y_plano 19; degraus_x_plano 89 |
| Oil/Knife/Knife Stain | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N3 | padrao | velha | degraus_x_plano 7 |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N1 | padrao | velha | degraus_y_plano 9; degraus_x_plano 51 |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N1 | liso | velha | degraus_y_plano 24; degraus_x_plano 99 |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N3 | padrao | velha | manchas_azul_plano 5.88; km_p99_plano 37.70; km_max_plano 47.50; degraus_y_plano 20; degraus_x_plano 79 |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 38.30; km_max_plano 42.50; degraus_y_plano 31; degraus_x_plano 169 |
| Oil/Knife/Knife Stain | P40/W0.5/pr1/N3 | liso | pigmento | degraus_y_plano 3 |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 1 |
| Oil/Knife/Knife Stain | P40/W1/pr1/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr1/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr1/N3 | padrao | velha | degraus_y_plano 6; degraus_x_plano 28 |
| Oil/Knife/Knife Stain | P40/W1/pr1/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P40/W1/pr1/N3 | liso | velha | degraus_y_plano 5; degraus_x_plano 30 |
| Oil/Knife/Knife Stain | P40/W1/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N3 | padrao | velha | manchas_azul_plano 4.43; km_p99_plano 23.40; km_max_plano 24.40; degraus_y_plano 3; degraus_x_plano 19 |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N3 | liso | velha | degraus_y_plano 4; degraus_x_plano 86 |
| Oil/Knife/Knife Stain | P600/W0/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0/pr1/N1 | padrao | velha | manchas_azul_plano 4.75; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 64 |
| Oil/Knife/Knife Stain | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0/pr1/N1 | liso | velha | km_p99_plano 24.60; km_max_plano 26.90; degraus_y_plano 12; degraus_x_plano 153 |
| Oil/Knife/Knife Stain | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 25.40; degraus_y_plano 11; degraus_x_plano 41 |
| Oil/Knife/Knife Stain | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.20; degraus_y_plano 19; degraus_x_plano 89 |
| Oil/Knife/Knife Stain | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; degraus_y_plano 3; degraus_x_plano 17 |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N3 | liso | velha | degraus_y_plano 5; degraus_x_plano 68 |
| Oil/Knife/Knife Stain | P600/W0.5/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N1 | padrao | velha | manchas_azul_plano 4.95; km_p99_plano 36.60; km_max_plano 43.30; degraus_y_plano 11; degraus_x_plano 95 |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 32.60; km_max_plano 34.40; degraus_y_plano 17; degraus_x_plano 166 |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 38.50; km_max_plano 55.30; degraus_y_plano 26; degraus_x_plano 98 |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 36.50; km_max_plano 47.90; degraus_y_plano 31; degraus_x_plano 162 |
| Oil/Knife/Knife Stain | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N3 | padrao | velha | degraus_x_plano 31 |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N3 | liso | velha | degraus_y_plano 5; degraus_x_plano 26 |
| Oil/Knife/Knife Stain | P600/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 42.40; km_max_plano 47.50; degraus_y_plano 10; degraus_x_plano 83 |
| Oil/Knife/Knife Stain | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W1/pr1/N1 | liso | velha | km_p99_plano 38.20; km_max_plano 39.20; degraus_y_plano 23; degraus_x_plano 172 |
| Oil/Knife/Knife Stain | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 34.10; km_max_plano 50.40; degraus_y_plano 24; degraus_x_plano 81 |
| Oil/Knife/Knife Stain | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P600/W1/pr1/N3 | liso | velha | manchas_azul_plano 1.38; km_p99_plano 37.00; km_max_plano 63.10; degraus_y_plano 29; degraus_x_plano 165 |
| Oil/Knife/Knife Stain | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N3 | padrao | velha | manchas_azul_plano 4.43; km_p99_plano 23.40; km_max_plano 24.40; degraus_y_plano 3; degraus_x_plano 19 |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N3 | liso | velha | degraus_y_plano 4; degraus_x_plano 86 |
| Oil/Knife/Knife Stain | P2000/W0/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N1 | padrao | velha | manchas_azul_plano 4.75; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 64 |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 24.60; km_max_plano 26.90; degraus_y_plano 12; degraus_x_plano 153 |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 25.40; degraus_y_plano 11; degraus_x_plano 41 |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.20; degraus_y_plano 19; degraus_x_plano 89 |
| Oil/Knife/Knife Stain | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; degraus_x_plano 15 |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N3 | liso | velha | degraus_y_plano 3; degraus_x_plano 75 |
| Oil/Knife/Knife Stain | P2000/W0.5/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N1 | padrao | velha | manchas_azul_plano 3.95; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 61 |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 25.10; km_max_plano 26.90; degraus_y_plano 11; degraus_x_plano 151 |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 40 |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.90; degraus_y_plano 20; degraus_x_plano 88 |
| Oil/Knife/Knife Stain | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; degraus_y_plano 3; degraus_x_plano 24 |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N3 | liso | velha | degraus_y_plano 4; degraus_x_plano 63 |
| Oil/Knife/Knife Stain | P2000/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N1 | padrao | velha | manchas_azul_plano 4.59; km_p99_plano 40.00; km_max_plano 44.70; degraus_y_plano 13; degraus_x_plano 108 |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 37.90; km_max_plano 39.70; degraus_y_plano 23; degraus_x_plano 177 |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 37.90; km_max_plano 53.90; degraus_y_plano 26; degraus_x_plano 108 |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 35.60; km_max_plano 54.00; degraus_y_plano 36; degraus_x_plano 166 |
| Oil/Knife/Knife Stain | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P40/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Filbert | P40/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P40/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Filbert | P40/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 9 |
| Oil/Flat/Filbert | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P40/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 9 |
| Oil/Flat/Filbert | P40/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.60; km_max_plano 28.20; furos 25.65; degraus_y_plano 17 |
| Oil/Flat/Filbert | P40/W0/pr0.6/N1 | padrao | pigmento | furos 6.22 |
| Oil/Flat/Filbert | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.60; km_max_plano 28.20; furos 25.65; degraus_y_plano 17 |
| Oil/Flat/Filbert | P40/W0/pr0.6/N1 | liso | pigmento | furos 6.22 |
| Oil/Flat/Filbert | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 21 |
| Oil/Flat/Filbert | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 21 |
| Oil/Flat/Filbert | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 25.40; degraus_y_plano 18 |
| Oil/Flat/Filbert | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P40/W0/pr1/N1 | liso | velha | km_p99_plano 19.70; km_max_plano 25.40; degraus_y_plano 18 |
| Oil/Flat/Filbert | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.80; degraus_y_plano 7 |
| Oil/Flat/Filbert | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.80; degraus_y_plano 7 |
| Oil/Flat/Filbert | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 16 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 16 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 43.30; km_max_plano 44.50; furos 46.25; degraus_y_plano 25 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N3 | padrao | pigmento | furos 14.32 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 43.30; km_max_plano 44.50; furos 46.25; degraus_y_plano 25 |
| Oil/Flat/Filbert | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 14.22 |
| Oil/Flat/Filbert | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 44.60; km_max_plano 50.60; degraus_y_plano 20 |
| Oil/Flat/Filbert | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 44.60; km_max_plano 50.60; degraus_y_plano 20 |
| Oil/Flat/Filbert | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 25.80; km_max_plano 42.70; degraus_y_plano 27 |
| Oil/Flat/Filbert | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 25.80; km_max_plano 43.50; degraus_y_plano 27 |
| Oil/Flat/Filbert | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 2 |
| Oil/Flat/Filbert | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.6/N3 | padrao | velha | degraus_y_plano 10 |
| Oil/Flat/Filbert | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr0.6/N3 | liso | velha | degraus_y_plano 13 |
| Oil/Flat/Filbert | P40/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 15 |
| Oil/Flat/Filbert | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Flat/Filbert | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 15 |
| Oil/Flat/Filbert | P40/W1/pr1/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Flat/Filbert | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 36.60; km_max_plano 37.90; degraus_y_plano 22 |
| Oil/Flat/Filbert | P40/W1/pr1/N3 | padrao | pigmento | degraus_y_plano 3 |
| Oil/Flat/Filbert | P40/W1/pr1/N3 | liso | velha | km_p99_plano 36.50; km_max_plano 38.00; degraus_y_plano 22 |
| Oil/Flat/Filbert | P40/W1/pr1/N3 | liso | pigmento | degraus_y_plano 3 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 9 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 9 |
| Oil/Flat/Filbert | P600/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.60; km_max_plano 28.20; furos 25.65; degraus_y_plano 17 |
| Oil/Flat/Filbert | P600/W0/pr0.6/N1 | padrao | pigmento | furos 6.22 |
| Oil/Flat/Filbert | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.60; km_max_plano 28.20; furos 25.65; degraus_y_plano 17 |
| Oil/Flat/Filbert | P600/W0/pr0.6/N1 | liso | pigmento | furos 6.22 |
| Oil/Flat/Filbert | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 21 |
| Oil/Flat/Filbert | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 21 |
| Oil/Flat/Filbert | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 25.40; degraus_y_plano 18 |
| Oil/Flat/Filbert | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W0/pr1/N1 | liso | velha | km_p99_plano 19.70; km_max_plano 25.40; degraus_y_plano 18 |
| Oil/Flat/Filbert | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.80; degraus_y_plano 7 |
| Oil/Flat/Filbert | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.80; degraus_y_plano 7 |
| Oil/Flat/Filbert | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 5 |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 5 |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 7 |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 5 |
| Oil/Flat/Filbert | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 35.20; km_max_plano 38.70; furos 57.60; degraus_y_plano 18 |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N1 | padrao | pigmento | furos 13.15 |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 35.20; km_max_plano 38.70; furos 57.60; degraus_y_plano 18 |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N1 | liso | pigmento | furos 13.15 |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 35.30; km_max_plano 48.40; degraus_y_plano 30 |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 35.30; km_max_plano 48.40; degraus_y_plano 30 |
| Oil/Flat/Filbert | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 42.40; km_max_plano 63.70; degraus_y_plano 22 |
| Oil/Flat/Filbert | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 42.40; km_max_plano 63.70; degraus_y_plano 22 |
| Oil/Flat/Filbert | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 28.40; km_max_plano 43.20; degraus_y_plano 32 |
| Oil/Flat/Filbert | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 28.40; km_max_plano 43.20; degraus_y_plano 32 |
| Oil/Flat/Filbert | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P600/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 31.50; km_max_plano 32.90; furos 94.61; degraus_y_plano 19 |
| Oil/Flat/Filbert | P600/W1/pr0.6/N1 | padrao | pigmento | furos 31.77; degraus_y_plano 5 |
| Oil/Flat/Filbert | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 31.50; km_max_plano 32.90; furos 94.61; degraus_y_plano 19 |
| Oil/Flat/Filbert | P600/W1/pr0.6/N1 | liso | pigmento | furos 31.77; degraus_y_plano 5 |
| Oil/Flat/Filbert | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 28.40; km_max_plano 44.90; degraus_y_plano 27 |
| Oil/Flat/Filbert | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 28.40; km_max_plano 44.90; degraus_y_plano 27 |
| Oil/Flat/Filbert | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P600/W1/pr1/N1 | padrao | velha | manchas_azul_plano 3.93; km_p99_plano 36.50; km_max_plano 63.70; furos 0.21; degraus_y_plano 21 |
| Oil/Flat/Filbert | P600/W1/pr1/N1 | padrao | pigmento | furos 0.21 |
| Oil/Flat/Filbert | P600/W1/pr1/N1 | liso | velha | manchas_azul_plano 3.93; km_p99_plano 36.50; km_max_plano 63.70; furos 0.21; degraus_y_plano 20 |
| Oil/Flat/Filbert | P600/W1/pr1/N1 | liso | pigmento | furos 0.21 |
| Oil/Flat/Filbert | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 23.80; km_max_plano 41.20; degraus_y_plano 19 |
| Oil/Flat/Filbert | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P600/W1/pr1/N3 | liso | velha | km_p99_plano 23.80; km_max_plano 41.20; degraus_y_plano 19 |
| Oil/Flat/Filbert | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 9 |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 9 |
| Oil/Flat/Filbert | P2000/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.60; km_max_plano 28.20; furos 25.65; degraus_y_plano 17 |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N1 | padrao | pigmento | furos 6.22 |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.60; km_max_plano 28.20; furos 25.65; degraus_y_plano 17 |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N1 | liso | pigmento | furos 6.22 |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 21 |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 21 |
| Oil/Flat/Filbert | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 25.40; degraus_y_plano 18 |
| Oil/Flat/Filbert | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 19.70; km_max_plano 25.40; degraus_y_plano 18 |
| Oil/Flat/Filbert | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.80; degraus_y_plano 7 |
| Oil/Flat/Filbert | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.80; degraus_y_plano 7 |
| Oil/Flat/Filbert | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 4 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 4 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 7 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 7 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 23.00; km_max_plano 29.00; furos 31.43; degraus_y_plano 17 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N1 | padrao | pigmento | furos 6.54 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.00; km_max_plano 29.00; furos 31.43; degraus_y_plano 17 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N1 | liso | pigmento | furos 6.54 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 20 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 20 |
| Oil/Flat/Filbert | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 20.50; km_max_plano 25.30; degraus_y_plano 18 |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 20.50; km_max_plano 25.30; degraus_y_plano 18 |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 26.50; degraus_y_plano 7 |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 26.50; degraus_y_plano 7 |
| Oil/Flat/Filbert | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 10 |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 9 |
| Oil/Flat/Filbert | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 42.00; km_max_plano 45.00; furos 52.42; degraus_y_plano 22 |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N1 | padrao | pigmento | furos 14.82; degraus_y_plano 2 |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 42.00; km_max_plano 45.00; furos 52.42; degraus_y_plano 22 |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N1 | liso | pigmento | furos 14.82; degraus_y_plano 2 |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 28.50; km_max_plano 42.50; degraus_y_plano 33 |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 28.50; km_max_plano 42.50; degraus_y_plano 34 |
| Oil/Flat/Filbert | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 34.70; km_max_plano 75.90; degraus_y_plano 21 |
| Oil/Flat/Filbert | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 34.70; km_max_plano 77.10; degraus_y_plano 21 |
| Oil/Flat/Filbert | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 25.80; km_max_plano 34.60; degraus_y_plano 34 |
| Oil/Flat/Filbert | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 25.80; km_max_plano 35.20; degraus_y_plano 34 |
| Oil/Flat/Filbert | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 25.00; furos 60.76; degraus_y_plano 5 |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N1 | padrao | pigmento | furos 54.69 |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 23.50; furos 51.69; degraus_y_plano 6 |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N1 | liso | pigmento | furos 40.76 |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; furos 2.42; degraus_y_plano 10; degraus_x_plano 56 |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N3 | padrao | pigmento | furos 0.47 |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N3 | liso | velha | km_p99_plano 21.10; km_max_plano 26.60; furos 0.73; degraus_y_plano 10; degraus_x_plano 118 |
| Oil/Knife/Knife Dry | P40/W0/pr0.2/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 25.20; degraus_y_plano 9; degraus_x_plano 14 |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 24.70; furos 0.05; degraus_y_plano 9; degraus_x_plano 20 |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 17.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 17.80; km_max_plano 25.30; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P40/W0/pr0.6/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 17.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0/pr1/N1 | liso | velha | km_p99_plano 17.00; km_max_plano 23.40; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P40/W0/pr1/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 16.50; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0/pr1/N3 | liso | velha | km_p99_plano 16.50; km_max_plano 23.40; furos 0.05; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P40/W0/pr1/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 1 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N1 | liso | pigmento | furos 98.91 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 30.10; furos 75.52; degraus_y_plano 8; degraus_x_plano 58 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 70.03 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 25.00; km_max_plano 33.50; furos 62.06; degraus_y_plano 13; degraus_x_plano 155 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 55.16 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 24.00; km_max_plano 34.50; furos 4.04; degraus_y_plano 10; degraus_x_plano 55 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N1 | padrao | pigmento | furos 2.06 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 33.80; furos 0.99; degraus_y_plano 12; degraus_x_plano 94 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N1 | liso | pigmento | furos 0.21 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 22.10; km_max_plano 45.90; degraus_y_plano 14; degraus_x_plano 12 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 38.00; degraus_y_plano 14; degraus_x_plano 21 |
| Oil/Knife/Knife Dry | P40/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 21.90; km_max_plano 41.10; degraus_y_plano 9; degraus_x_plano 6 |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 20.90; km_max_plano 37.60; degraus_y_plano 8; degraus_x_plano 7 |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 14 |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 24.10; degraus_y_plano 14 |
| Oil/Knife/Knife Dry | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N3 | padrao | velha | furos 100.00; degraus_x_plano 6 |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 3; degraus_x_plano 36 |
| Oil/Knife/Knife Dry | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N1 | padrao | velha | furos 100.00; degraus_y_plano 11; degraus_x_plano 50 |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N1 | liso | velha | furos 100.00; degraus_y_plano 12; degraus_x_plano 75 |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N3 | padrao | velha | km_p99_plano 24.00; km_max_plano 32.50; degraus_y_plano 17; degraus_x_plano 53 |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N3 | padrao | pigmento | furos 0.81 |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 32.80; degraus_y_plano 16; degraus_x_plano 67 |
| Oil/Knife/Knife Dry | P40/W1/pr0.6/N3 | liso | pigmento | furos 0.68 |
| Oil/Knife/Knife Dry | P40/W1/pr1/N1 | padrao | velha | km_p99_plano 25.80; km_max_plano 33.20; furos 0.91; degraus_y_plano 14; degraus_x_plano 34 |
| Oil/Knife/Knife Dry | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Dry | P40/W1/pr1/N1 | liso | velha | km_p99_plano 24.70; km_max_plano 34.10; furos 0.13; degraus_y_plano 9; degraus_x_plano 59 |
| Oil/Knife/Knife Dry | P40/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 22.10; km_max_plano 29.60; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Dry | P40/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P40/W1/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 35.10; degraus_y_plano 13; degraus_x_plano 11 |
| Oil/Knife/Knife Dry | P40/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 25.00; furos 60.76; degraus_y_plano 5 |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N1 | padrao | pigmento | furos 54.69 |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 23.50; furos 51.69; degraus_y_plano 6 |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N1 | liso | pigmento | furos 40.76 |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; furos 2.42; degraus_y_plano 10; degraus_x_plano 56 |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N3 | padrao | pigmento | furos 0.47 |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N3 | liso | velha | km_p99_plano 21.10; km_max_plano 26.60; furos 0.73; degraus_y_plano 10; degraus_x_plano 118 |
| Oil/Knife/Knife Dry | P600/W0/pr0.2/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 25.20; degraus_y_plano 9; degraus_x_plano 14 |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 24.70; furos 0.05; degraus_y_plano 9; degraus_x_plano 20 |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 17.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 17.80; km_max_plano 25.30; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P600/W0/pr0.6/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 17.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0/pr1/N1 | liso | velha | km_p99_plano 17.00; km_max_plano 23.40; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P600/W0/pr1/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 16.50; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0/pr1/N3 | liso | velha | km_p99_plano 16.50; km_max_plano 23.40; furos 0.05; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P600/W0/pr1/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 68.26; degraus_y_plano 5 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 62.89 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 56.88; degraus_y_plano 5 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 50.47 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 25.40; km_max_plano 32.50; furos 4.92; degraus_y_plano 10; degraus_x_plano 73 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 2.21 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 25.20; km_max_plano 36.30; furos 2.45; degraus_y_plano 10; degraus_x_plano 158 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 0.83 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 35.60; furos 0.03; degraus_y_plano 10; degraus_x_plano 34 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 45.40; furos 0.05; degraus_y_plano 11; degraus_x_plano 53 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 20.60; km_max_plano 44.10; degraus_y_plano 14; degraus_x_plano 22 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 38.90; degraus_y_plano 14; degraus_x_plano 26 |
| Oil/Knife/Knife Dry | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 19.90; km_max_plano 33.40; degraus_y_plano 15; degraus_x_plano 11 |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 19.70; km_max_plano 37.60; furos 0.03; degraus_y_plano 14; degraus_x_plano 14 |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 13 |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 23.70; degraus_y_plano 14 |
| Oil/Knife/Knife Dry | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 25.60; furos 90.94; degraus_y_plano 4; degraus_x_plano 4 |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N1 | padrao | pigmento | furos 85.68 |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 81.80; degraus_y_plano 4; degraus_x_plano 5 |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N1 | liso | pigmento | furos 70.23 |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N3 | padrao | velha | km_p99_plano 25.10; km_max_plano 32.50; furos 13.10; degraus_y_plano 13; degraus_x_plano 60 |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N3 | padrao | pigmento | furos 9.38 |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N3 | liso | velha | km_p99_plano 25.20; km_max_plano 36.30; furos 6.90; degraus_y_plano 13; degraus_x_plano 141 |
| Oil/Knife/Knife Dry | P600/W1/pr0.2/N3 | liso | pigmento | furos 4.74 |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 20.80; km_max_plano 30.00; furos 0.08; degraus_y_plano 10; degraus_x_plano 36 |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N1 | padrao | pigmento | furos 0.03 |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 22.20; km_max_plano 43.40; degraus_y_plano 9; degraus_x_plano 29 |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 19.10; km_max_plano 28.10; degraus_y_plano 12; degraus_x_plano 8 |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 19.10; km_max_plano 28.70; degraus_y_plano 12; degraus_x_plano 12 |
| Oil/Knife/Knife Dry | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 18.50; km_max_plano 30.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W1/pr1/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 29.90; degraus_y_plano 8; degraus_x_plano 6 |
| Oil/Knife/Knife Dry | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 18.90; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Dry | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P600/W1/pr1/N3 | liso | velha | km_p99_plano 18.90; km_max_plano 23.40; degraus_y_plano 14 |
| Oil/Knife/Knife Dry | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 25.00; furos 60.76; degraus_y_plano 5 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N1 | padrao | pigmento | furos 54.69 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 23.50; furos 51.69; degraus_y_plano 6 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N1 | liso | pigmento | furos 40.76 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; furos 2.42; degraus_y_plano 10; degraus_x_plano 56 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 0.47 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N3 | liso | velha | km_p99_plano 21.10; km_max_plano 26.60; furos 0.73; degraus_y_plano 10; degraus_x_plano 118 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.2/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 25.20; degraus_y_plano 9; degraus_x_plano 14 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 24.70; furos 0.05; degraus_y_plano 9; degraus_x_plano 20 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 17.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 17.80; km_max_plano 25.30; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P2000/W0/pr0.6/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 17.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 17.00; km_max_plano 23.40; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 16.50; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 16.50; km_max_plano 23.40; furos 0.05; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P2000/W0/pr1/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 62.81; degraus_y_plano 5 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N1 | padrao | pigmento | furos 56.61 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 53.39; degraus_y_plano 6 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 42.63 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 21.00; km_max_plano 26.90; furos 2.84; degraus_y_plano 11; degraus_x_plano 54 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 0.62 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 20.90; km_max_plano 26.90; furos 0.99; degraus_y_plano 10; degraus_x_plano 115 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 0.13 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 24.40; degraus_y_plano 10; degraus_x_plano 15 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 18.80; km_max_plano 26.90; furos 0.05; degraus_y_plano 9; degraus_x_plano 19 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 17.90; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 17.90; km_max_plano 23.40; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr0.6/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 17.80; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 17.00; km_max_plano 23.40; furos 0.05; degraus_y_plano 8 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N1 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 17.00; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 16.90; km_max_plano 23.40; furos 0.05; degraus_y_plano 9 |
| Oil/Knife/Knife Dry | P2000/W0.5/pr1/N3 | liso | pigmento | furos 0.05 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 69.90; degraus_y_plano 4; degraus_x_plano 3 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 64.56 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 57.92; degraus_y_plano 5 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N1 | liso | pigmento | furos 51.12 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 32.20; furos 5.18; degraus_y_plano 13; degraus_x_plano 75 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 2.81 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N3 | liso | velha | km_p99_plano 24.10; km_max_plano 36.20; furos 2.71; degraus_y_plano 12; degraus_x_plano 153 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.2/N3 | liso | pigmento | furos 1.02 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 22.10; km_max_plano 38.50; degraus_y_plano 9; degraus_x_plano 37 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 22.00; km_max_plano 45.90; furos 0.05; degraus_y_plano 14; degraus_x_plano 51 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 19.20; km_max_plano 32.90; degraus_y_plano 13; degraus_x_plano 21 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 19.40; km_max_plano 30.50; degraus_y_plano 13; degraus_x_plano 26 |
| Oil/Knife/Knife Dry | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 19.20; km_max_plano 27.10; degraus_y_plano 11; degraus_x_plano 12 |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 19.40; km_max_plano 33.60; furos 0.03; degraus_y_plano 11; degraus_x_plano 14 |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 15 |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 15 |
| Oil/Knife/Knife Dry | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N1 | padrao | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N1 | liso | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N1 | liso | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 22.70; km_max_plano 26.00; furos 24.24; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.70; km_max_plano 26.00; furos 24.24; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 23.50; km_max_plano 26.90; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N1 | liso | velha | km_p99_plano 23.50; km_max_plano 26.90; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 28.20; degraus_y_plano 15 |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 28.20; degraus_y_plano 15 |
| Oil/Flat/Filbert Dry | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N3 | padrao | velha | degraus_y_plano 3 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N3 | liso | velha | degraus_y_plano 3 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N1 | padrao | velha | degraus_y_plano 7 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N1 | liso | velha | degraus_y_plano 7 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 26.10; km_max_plano 30.50; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 26.10; km_max_plano 30.50; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P40/W0.5/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P40/W1/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N1 | padrao | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N1 | liso | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N1 | liso | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 22.70; km_max_plano 26.00; furos 24.24; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.70; km_max_plano 26.00; furos 24.24; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 23.50; km_max_plano 26.90; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N1 | liso | velha | km_p99_plano 23.50; km_max_plano 26.90; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 28.20; degraus_y_plano 15 |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 28.20; degraus_y_plano 15 |
| Oil/Flat/Filbert Dry | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 9 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 9 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 21.10; km_max_plano 22.50; furos 51.02; degraus_y_plano 11 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N3 | padrao | pigmento | furos 1.35 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 21.10; km_max_plano 22.40; furos 51.04; degraus_y_plano 11 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr0.6/N3 | liso | pigmento | furos 1.35 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 29.40; km_max_plano 30.40; degraus_y_plano 14 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 29.40; km_max_plano 30.40; degraus_y_plano 14 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 25.60; km_max_plano 33.30; degraus_y_plano 19 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 25.60; km_max_plano 33.30; degraus_y_plano 19 |
| Oil/Flat/Filbert Dry | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 7 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N1 | liso | velha | degraus_y_plano 7 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N3 | padrao | velha | furos 100.00; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N3 | padrao | pigmento | furos 26.15 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N3 | liso | velha | furos 100.00; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P600/W1/pr0.6/N3 | liso | pigmento | furos 26.15 |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 27.40; km_max_plano 29.60; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N1 | liso | velha | km_p99_plano 27.40; km_max_plano 29.60; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 24.60; km_max_plano 33.50; degraus_y_plano 12 |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N3 | liso | velha | km_p99_plano 24.60; km_max_plano 33.50; degraus_y_plano 12 |
| Oil/Flat/Filbert Dry | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N1 | padrao | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N1 | liso | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N1 | liso | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 22.70; km_max_plano 26.00; furos 24.24; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.70; km_max_plano 26.00; furos 24.24; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 23.50; km_max_plano 26.90; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 23.50; km_max_plano 26.90; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 28.20; degraus_y_plano 15 |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 28.20; degraus_y_plano 15 |
| Oil/Flat/Filbert Dry | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 6 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N1 | liso | pigmento | degraus_y_plano 2 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 21.70; km_max_plano 25.60; furos 28.70; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 21.70; km_max_plano 25.60; furos 28.70; degraus_y_plano 10 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 12 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 12 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 16 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 16 |
| Oil/Flat/Filbert Dry | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 11 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N1 | liso | velha | degraus_y_plano 11 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 28.80; km_max_plano 30.30; furos 50.91; degraus_y_plano 14 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N3 | padrao | pigmento | furos 2.06 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 28.80; km_max_plano 30.30; furos 50.91; degraus_y_plano 14 |
| Oil/Flat/Filbert Dry | P2000/W1/pr0.6/N3 | liso | pigmento | furos 2.06 |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 30.90; km_max_plano 33.00; degraus_y_plano 19; degraus_x_plano 5 |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 30.90; km_max_plano 33.00; degraus_y_plano 18; degraus_x_plano 5 |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 23.90; km_max_plano 34.20; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 24.00; km_max_plano 34.20; degraus_y_plano 13 |
| Oil/Flat/Filbert Dry | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P40/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N1 | liso | pigmento | furos 95.16 |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.90; furos 94.45; degraus_y_plano 4; degraus_x_plano 3 |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N3 | padrao | pigmento | furos 73.41 |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 98.18; degraus_y_plano 4; degraus_x_plano 16 |
| Oil/Knife/Knife Textured | P40/W0/pr0.6/N3 | liso | pigmento | furos 65.29 |
| Oil/Knife/Knife Textured | P40/W0/pr1/N1 | padrao | velha | manchas_azul_plano 1.29; km_p99_plano 22.70; km_max_plano 27.20; degraus_y_plano 3; degraus_x_plano 6 |
| Oil/Knife/Knife Textured | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P40/W0/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 4; degraus_x_plano 26 |
| Oil/Knife/Knife Textured | P40/W0/pr1/N1 | liso | pigmento | furos 0.55 |
| Oil/Knife/Knife Textured | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; furos 0.23; degraus_y_plano 8 |
| Oil/Knife/Knife Textured | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.90; km_max_plano 23.40; degraus_y_plano 7 |
| Oil/Knife/Knife Textured | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N3 | padrao | velha | degraus_x_plano 10 |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N3 | liso | velha | furos 100.00; degraus_y_plano 3; degraus_x_plano 28 |
| Oil/Knife/Knife Textured | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 98.96 |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 48.00; km_max_plano 48.90; degraus_y_plano 7; degraus_x_plano 15 |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N1 | liso | velha | degraus_y_plano 11; degraus_x_plano 87 |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N3 | padrao | velha | manchas_azul_plano 1.72; km_p99_plano 38.30; km_max_plano 50.00; degraus_y_plano 13; degraus_x_plano 18 |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 37.80; km_max_plano 48.10; furos 0.16; degraus_y_plano 16; degraus_x_plano 82 |
| Oil/Knife/Knife Textured | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 3 |
| Oil/Knife/Knife Textured | P40/W1/pr1/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 2 |
| Oil/Knife/Knife Textured | P40/W1/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P40/W1/pr1/N3 | padrao | velha | degraus_y_plano 12; degraus_x_plano 25 |
| Oil/Knife/Knife Textured | P40/W1/pr1/N3 | padrao | pigmento | degraus_y_plano 5 |
| Oil/Knife/Knife Textured | P40/W1/pr1/N3 | liso | velha | degraus_y_plano 14; degraus_x_plano 62 |
| Oil/Knife/Knife Textured | P40/W1/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N1 | liso | pigmento | furos 95.16 |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.90; furos 94.45; degraus_y_plano 4; degraus_x_plano 3 |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N3 | padrao | pigmento | furos 73.41 |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 98.18; degraus_y_plano 4; degraus_x_plano 16 |
| Oil/Knife/Knife Textured | P600/W0/pr0.6/N3 | liso | pigmento | furos 65.29 |
| Oil/Knife/Knife Textured | P600/W0/pr1/N1 | padrao | velha | manchas_azul_plano 1.29; km_p99_plano 22.70; km_max_plano 27.20; degraus_y_plano 3; degraus_x_plano 6 |
| Oil/Knife/Knife Textured | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W0/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 4; degraus_x_plano 26 |
| Oil/Knife/Knife Textured | P600/W0/pr1/N1 | liso | pigmento | furos 0.55 |
| Oil/Knife/Knife Textured | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; furos 0.23; degraus_y_plano 8 |
| Oil/Knife/Knife Textured | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.90; km_max_plano 23.40; degraus_y_plano 7 |
| Oil/Knife/Knife Textured | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 98.85; degraus_y_plano 4; degraus_x_plano 8 |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N3 | padrao | pigmento | furos 87.68 |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 21.60; furos 100.00; degraus_y_plano 6; degraus_x_plano 23 |
| Oil/Knife/Knife Textured | P600/W0.5/pr0.6/N3 | liso | pigmento | furos 86.85 |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N1 | padrao | velha | manchas_azul_plano 1.65; km_p99_plano 43.10; km_max_plano 48.40; degraus_y_plano 10; degraus_x_plano 35 |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 45.40; km_max_plano 51.20; degraus_y_plano 13; degraus_x_plano 132 |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 35.70; km_max_plano 55.10; furos 0.39; degraus_y_plano 11; degraus_x_plano 5 |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 34.60; km_max_plano 38.50; degraus_y_plano 15 |
| Oil/Knife/Knife Textured | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N3 | padrao | velha | degraus_y_plano 7; degraus_x_plano 52 |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N3 | padrao | pigmento | furos 98.72 |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N3 | liso | velha | furos 100.00; degraus_y_plano 8; degraus_x_plano 105 |
| Oil/Knife/Knife Textured | P600/W1/pr0.6/N3 | liso | pigmento | furos 95.89 |
| Oil/Knife/Knife Textured | P600/W1/pr1/N1 | padrao | velha | manchas_azul_plano 1.58; km_p99_plano 45.60; km_max_plano 51.90; degraus_y_plano 11; degraus_x_plano 36 |
| Oil/Knife/Knife Textured | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W1/pr1/N1 | liso | velha | km_p99_plano 46.60; km_max_plano 53.40; degraus_y_plano 15; degraus_x_plano 106 |
| Oil/Knife/Knife Textured | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 31.20; km_max_plano 48.00; degraus_y_plano 10; degraus_x_plano 8 |
| Oil/Knife/Knife Textured | P600/W1/pr1/N3 | padrao | pigmento | furos 0.05 |
| Oil/Knife/Knife Textured | P600/W1/pr1/N3 | liso | velha | km_p99_plano 28.70; km_max_plano 35.20; degraus_y_plano 10 |
| Oil/Knife/Knife Textured | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N1 | liso | pigmento | furos 95.16 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.90; furos 94.45; degraus_y_plano 4; degraus_x_plano 3 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N3 | padrao | pigmento | furos 73.41 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 98.18; degraus_y_plano 4; degraus_x_plano 16 |
| Oil/Knife/Knife Textured | P2000/W0/pr0.6/N3 | liso | pigmento | furos 65.29 |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N1 | padrao | velha | manchas_azul_plano 1.29; km_p99_plano 22.70; km_max_plano 27.20; degraus_y_plano 3; degraus_x_plano 6 |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 4; degraus_x_plano 26 |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N1 | liso | pigmento | furos 0.55 |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; furos 0.23; degraus_y_plano 8 |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.90; km_max_plano 23.40; degraus_y_plano 7 |
| Oil/Knife/Knife Textured | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N1 | liso | pigmento | furos 95.34 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 96.25; degraus_y_plano 4; degraus_x_plano 4 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N3 | padrao | pigmento | furos 78.15 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 99.61; degraus_y_plano 4; degraus_x_plano 15 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr0.6/N3 | liso | pigmento | furos 72.14 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N1 | padrao | velha | manchas_azul_plano 2.28; km_p99_plano 22.90; km_max_plano 25.90; degraus_y_plano 3; degraus_x_plano 6 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.50; degraus_y_plano 4; degraus_x_plano 32 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N1 | liso | pigmento | furos 0.78 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 24.80; furos 0.26; degraus_y_plano 7 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.10; degraus_y_plano 6 |
| Oil/Knife/Knife Textured | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 99.19; degraus_y_plano 7; degraus_x_plano 20 |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N3 | padrao | pigmento | furos 89.79 |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 23.40; furos 100.00; degraus_y_plano 7; degraus_x_plano 60 |
| Oil/Knife/Knife Textured | P2000/W1/pr0.6/N3 | liso | pigmento | furos 87.47 |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N1 | padrao | velha | manchas_azul_plano 2.42; km_p99_plano 41.70; km_max_plano 50.40; degraus_y_plano 12; degraus_x_plano 33 |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 40.50; km_max_plano 49.50; degraus_y_plano 14; degraus_x_plano 126 |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 29.90; km_max_plano 46.10; furos 0.39; degraus_y_plano 10; degraus_x_plano 7 |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 30.00; km_max_plano 34.50; degraus_y_plano 12 |
| Oil/Knife/Knife Textured | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 22.60; km_max_plano 26.50; furos 18.18; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N1 | padrao | pigmento | furos 5.55; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 22.60; km_max_plano 26.50; furos 18.18; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N1 | liso | pigmento | furos 5.55; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Flat Bristle | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 13 |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 13 |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 18.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 5; degraus_x_plano 21 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N1 | padrao | pigmento | degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 5; degraus_x_plano 19 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N1 | liso | pigmento | degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.60; km_max_plano 26.30; furos 51.28; degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N3 | padrao | pigmento | furos 1.48 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.60; km_max_plano 26.30; furos 51.28; degraus_y_plano 8 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 1.48 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 25.70; km_max_plano 30.00; degraus_y_plano 6 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 25.70; km_max_plano 30.00; degraus_y_plano 6 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 21.70; km_max_plano 28.40; degraus_y_plano 15 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 21.70; km_max_plano 26.90; degraus_y_plano 15 |
| Oil/Flat/Flat Bristle | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N3 | padrao | velha | degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N3 | liso | velha | degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N1 | liso | pigmento | degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 22.20; km_max_plano 22.80; degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N3 | liso | velha | km_p99_plano 22.20; km_max_plano 23.20; degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P40/W1/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 22.60; km_max_plano 26.50; furos 18.18; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N1 | padrao | pigmento | furos 5.55; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 22.60; km_max_plano 26.50; furos 18.18; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N1 | liso | pigmento | furos 5.55; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Flat Bristle | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 13 |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 13 |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 18.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 23.60; km_max_plano 24.90; furos 43.39; degraus_y_plano 5; degraus_x_plano 7 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N1 | padrao | pigmento | furos 11.07 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.60; km_max_plano 24.90; furos 43.41; degraus_y_plano 5; degraus_x_plano 7 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N1 | liso | pigmento | furos 11.07 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 30.00; degraus_y_plano 6 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 30.00; degraus_y_plano 6 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 22.60; km_max_plano 32.20; degraus_y_plano 7; degraus_x_plano 15 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 22.60; km_max_plano 32.20; degraus_y_plano 7; degraus_x_plano 15 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 16.00; km_max_plano 23.40; degraus_y_plano 15; degraus_x_plano 10 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 16.10; km_max_plano 23.40; degraus_y_plano 15; degraus_x_plano 10 |
| Oil/Flat/Flat Bristle | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 25.50; km_max_plano 27.10; furos 95.42; degraus_y_plano 5; degraus_x_plano 14 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N1 | padrao | pigmento | furos 18.83; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 25.50; km_max_plano 27.10; furos 95.42; degraus_y_plano 5; degraus_x_plano 14 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N1 | liso | pigmento | furos 18.83; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.80; km_max_plano 31.10; degraus_y_plano 6 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.80; km_max_plano 31.10; degraus_y_plano 6 |
| Oil/Flat/Flat Bristle | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 30.50; degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 30.50; degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 18.20; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Flat/Flat Bristle | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 22.60; km_max_plano 26.50; furos 18.18; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N1 | padrao | pigmento | furos 5.55; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 22.60; km_max_plano 26.50; furos 18.18; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N1 | liso | pigmento | furos 5.55; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 29.00; degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Flat Bristle | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 13 |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 13 |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 18.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 22.70; km_max_plano 26.60; furos 22.84; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N1 | padrao | pigmento | furos 6.95; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 22.70; km_max_plano 26.60; furos 22.84; degraus_y_plano 4 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N1 | liso | pigmento | furos 6.95; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 11; degraus_x_plano 8 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 11; degraus_x_plano 8 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Flat/Flat Bristle | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 1 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00; degraus_x_plano 18 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00; degraus_x_plano 15 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 28.70; km_max_plano 30.50; furos 46.35; degraus_y_plano 8; degraus_x_plano 42 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N1 | padrao | pigmento | furos 11.46 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 28.70; km_max_plano 30.50; furos 46.35; degraus_y_plano 8; degraus_x_plano 42 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N1 | liso | pigmento | furos 11.46 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 29.50; degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 29.50; degraus_y_plano 7 |
| Oil/Flat/Flat Bristle | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 31.50; degraus_y_plano 8; degraus_x_plano 8 |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 31.50; degraus_y_plano 10; degraus_x_plano 8 |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 16.50; km_max_plano 23.40; degraus_y_plano 20; degraus_x_plano 29 |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 16.50; km_max_plano 23.40; degraus_y_plano 20; degraus_x_plano 29 |
| Oil/Flat/Flat Bristle | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.90; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 26.90; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 24.70; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 24.70; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 25.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 25.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N3 | liso | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N1 | padrao | pigmento | furos 14.22 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N1 | liso | pigmento | furos 14.22 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 28.80; km_max_plano 38.10; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 28.80; km_max_plano 38.10; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 45.60; km_max_plano 48.40; furos 13.26; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N1 | padrao | pigmento | furos 10.65 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 45.60; km_max_plano 48.40; furos 13.26; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N1 | liso | pigmento | furos 10.60 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 26.20; km_max_plano 38.30; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 26.20; km_max_plano 38.30; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 41.80; km_max_plano 51.00; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 41.80; km_max_plano 51.00; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 24.60; km_max_plano 32.80; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 24.60; km_max_plano 33.00; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N1 | padrao | velha | degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N1 | liso | velha | degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 12 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 12 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N1 | liso | velha | degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N3 | padrao | velha | km_p99_plano 42.00; km_max_plano 45.90; furos 32.58; degraus_y_plano 13 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N3 | padrao | pigmento | furos 1.77 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N3 | liso | velha | km_p99_plano 41.00; km_max_plano 45.90; furos 33.12; degraus_y_plano 14 |
| Oil/Metallic/Metallic Flat | P40/W1/pr0.6/N3 | liso | pigmento | furos 1.90 |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 33.20; km_max_plano 41.60; degraus_y_plano 9 |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N3 | liso | velha | km_p99_plano 33.30; km_max_plano 41.60; degraus_y_plano 9 |
| Oil/Metallic/Metallic Flat | P40/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.90; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 26.90; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 24.70; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 24.70; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 25.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 25.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N3 | liso | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N1 | padrao | velha | km_p99_plano 40.90; km_max_plano 49.10; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N1 | liso | velha | km_p99_plano 40.90; km_max_plano 49.10; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 28.60; km_max_plano 35.70; degraus_y_plano 11 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 28.60; km_max_plano 35.90; degraus_y_plano 10 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 39.80; km_max_plano 55.90; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 39.80; km_max_plano 55.90; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 26.80; km_max_plano 30.00; degraus_y_plano 9 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 26.80; km_max_plano 30.00; degraus_y_plano 9 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 36.70; km_max_plano 59.30; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 36.70; km_max_plano 70.60; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 27.10; km_max_plano 35.00; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 27.10; km_max_plano 35.00; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N1 | padrao | velha | km_p99_plano 40.40; km_max_plano 46.80; furos 13.15; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N1 | padrao | pigmento | furos 12.84 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N1 | liso | velha | km_p99_plano 40.40; km_max_plano 46.80; furos 13.15; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N1 | liso | pigmento | furos 12.84 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N3 | padrao | velha | km_p99_plano 24.30; km_max_plano 34.80; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N3 | liso | velha | km_p99_plano 24.30; km_max_plano 34.80; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 35.20; km_max_plano 51.50; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 35.20; km_max_plano 51.50; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 30.60; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 30.60; degraus_y_plano 6 |
| Oil/Metallic/Metallic Flat | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 33.30; km_max_plano 54.00; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N1 | liso | velha | km_p99_plano 33.30; km_max_plano 54.00; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 19.80; km_max_plano 30.70; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N3 | liso | velha | km_p99_plano 19.80; km_max_plano 30.70; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.90; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 26.90; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 24.70; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 24.70; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 25.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 25.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.60; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 23.60; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 25.50; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 25.50; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 23.40; degraus_y_plano 3 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 17.90; km_max_plano 24.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 17.90; km_max_plano 24.40; degraus_y_plano 1 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 15.90; km_max_plano 23.40 |
| Oil/Metallic/Metallic Flat | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N1 | padrao | velha | km_p99_plano 31.80; km_max_plano 45.70; degraus_y_plano 7 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N1 | liso | velha | km_p99_plano 31.80; km_max_plano 45.80; degraus_y_plano 7 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N3 | padrao | velha | km_p99_plano 24.80; km_max_plano 35.00; degraus_y_plano 11 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N3 | liso | velha | km_p99_plano 24.80; km_max_plano 35.00; degraus_y_plano 11 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.2/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 30.70; km_max_plano 49.90; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 30.70; km_max_plano 49.70; degraus_y_plano 5 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 25.40; km_max_plano 33.00; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 25.40; km_max_plano 33.00; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 33.10; km_max_plano 73.50; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 33.10; km_max_plano 73.50; degraus_y_plano 4 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 27.30; km_max_plano 36.50; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 27.30; km_max_plano 36.50; degraus_y_plano 8 |
| Oil/Metallic/Metallic Flat | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 28.20; furos 12.53; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N1 | padrao | pigmento | furos 2.37 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 28.20; furos 12.53; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N1 | liso | pigmento | furos 2.37 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 10 |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 10 |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 18.60; km_max_plano 25.60; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 25.60; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N1 | padrao | pigmento | degraus_y_plano 4 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 7; degraus_x_plano 9 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N1 | liso | pigmento | degraus_y_plano 4 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 24.30; km_max_plano 27.20; furos 44.17; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N3 | padrao | pigmento | furos 0.60 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 24.10; km_max_plano 27.20; furos 44.17; degraus_y_plano 9 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 0.60 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 26.20; km_max_plano 30.00; degraus_y_plano 5; degraus_x_plano 3 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 26.30; km_max_plano 30.00; degraus_y_plano 5; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 30.90; degraus_y_plano 11; degraus_x_plano 6 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 32.00; degraus_y_plano 11; degraus_x_plano 6 |
| Oil/Flat/Tilted Shade | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 2 |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N1 | liso | velha | degraus_y_plano 1 |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Flat/Tilted Shade | P40/W1/pr0.6/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 6 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 6 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N1 | liso | pigmento | degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 22.30; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N3 | padrao | pigmento | furos 0.39 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N3 | liso | velha | km_p99_plano 22.30; km_max_plano 23.40; degraus_y_plano 10 |
| Oil/Flat/Tilted Shade | P40/W1/pr1/N3 | liso | pigmento | furos 0.31 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 28.20; furos 12.53; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N1 | padrao | pigmento | furos 2.37 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 28.20; furos 12.53; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N1 | liso | pigmento | furos 2.37 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 10 |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 10 |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 18.60; km_max_plano 25.60; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 25.60; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 1 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 1 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 22.50; km_max_plano 25.50; furos 35.76; degraus_y_plano 9; degraus_x_plano 11 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N1 | padrao | pigmento | furos 9.09 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 22.50; km_max_plano 25.50; furos 35.78; degraus_y_plano 9; degraus_x_plano 11 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N1 | liso | pigmento | furos 9.09 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 30.50; degraus_y_plano 9; degraus_x_plano 4 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 30.50; degraus_y_plano 9; degraus_x_plano 4 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 32.00; degraus_y_plano 7; degraus_x_plano 23 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 32.00; degraus_y_plano 7; degraus_x_plano 23 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 17.90; km_max_plano 29.30; degraus_y_plano 13; degraus_x_plano 19 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 17.90; km_max_plano 28.60; degraus_y_plano 13; degraus_x_plano 19 |
| Oil/Flat/Tilted Shade | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 25.80; km_max_plano 26.80; furos 89.19; degraus_y_plano 5; degraus_x_plano 16 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N1 | padrao | pigmento | furos 18.18 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 25.80; km_max_plano 26.80; furos 89.19; degraus_y_plano 5; degraus_x_plano 16 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N1 | liso | pigmento | furos 18.18 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.70; km_max_plano 30.50; degraus_y_plano 9 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.70; km_max_plano 30.50; degraus_y_plano 9 |
| Oil/Flat/Tilted Shade | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 33.40; degraus_y_plano 9 |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 33.40; degraus_y_plano 9 |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 19.30; km_max_plano 28.40; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N3 | liso | velha | km_p99_plano 19.70; km_max_plano 28.40; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 28.20; furos 12.53; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N1 | padrao | pigmento | furos 2.37 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 28.20; furos 12.53; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N1 | liso | pigmento | furos 2.37 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 10 |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 10 |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 18.60; km_max_plano 25.60; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 25.60; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 27.40; furos 17.03; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N1 | padrao | pigmento | furos 3.46; degraus_y_plano 1 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 27.40; furos 17.03; degraus_y_plano 8 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N1 | liso | pigmento | furos 3.46; degraus_y_plano 1 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 25.90; degraus_y_plano 8; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 25.90; degraus_y_plano 8; degraus_x_plano 5 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 21.40; km_max_plano 25.10; degraus_y_plano 11; degraus_x_plano 6 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 21.40; km_max_plano 25.10; degraus_y_plano 11; degraus_x_plano 6 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 4 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 4 |
| Oil/Flat/Tilted Shade | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 1 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 1 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 28.50; km_max_plano 30.90; furos 37.63; degraus_y_plano 10; degraus_x_plano 36 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N1 | padrao | pigmento | furos 9.95 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 28.50; km_max_plano 30.90; furos 37.63; degraus_y_plano 10; degraus_x_plano 36 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N1 | liso | pigmento | furos 9.95 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.50; km_max_plano 31.60; degraus_y_plano 10; degraus_x_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.50; km_max_plano 31.80; degraus_y_plano 10; degraus_x_plano 3 |
| Oil/Flat/Tilted Shade | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 31.80; degraus_y_plano 9; degraus_x_plano 17 |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 31.80; degraus_y_plano 9; degraus_x_plano 17 |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 17.80; km_max_plano 27.20; degraus_y_plano 17; degraus_x_plano 37 |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 17.80; km_max_plano 27.20; degraus_y_plano 17; degraus_x_plano 37 |
| Oil/Flat/Tilted Shade | P2000/W1/pr1/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 6 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 6 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.70; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.70; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.60; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.60; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 19 |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N1 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N1 | liso | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 19 |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N1 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.50; degraus_y_plano 15 |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.50; degraus_y_plano 15 |
| ExpressOil/Round/Express Oil | P40/W0/pr1/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 9 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 9 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N3 | padrao | velha | degraus_y_plano 16; degraus_x_plano 3 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N3 | liso | velha | degraus_y_plano 15; degraus_x_plano 3 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N1 | padrao | velha | degraus_y_plano 28; degraus_x_plano 19 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N1 | liso | velha | degraus_y_plano 27; degraus_x_plano 19 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 42.70; km_max_plano 46.00; degraus_y_plano 27 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 42.80; km_max_plano 46.30; degraus_y_plano 27 |
| ExpressOil/Round/Express Oil | P40/W0.5/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N3 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N3 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 3 |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 3 |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N3 | padrao | velha | degraus_y_plano 15 |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N3 | liso | velha | degraus_y_plano 16 |
| ExpressOil/Round/Express Oil | P40/W1/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 6 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 6 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.70; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.70; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.60; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.60; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 19 |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N1 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N1 | liso | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 19 |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N1 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.50; degraus_y_plano 15 |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.50; degraus_y_plano 15 |
| ExpressOil/Round/Express Oil | P600/W0/pr1/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 7; degraus_x_plano 6 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 7; degraus_x_plano 8 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 19; degraus_x_plano 20 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 18; degraus_x_plano 20 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 40.40; km_max_plano 45.30; furos 50.70; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N3 | padrao | pigmento | furos 17.06 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 40.40; km_max_plano 45.30; furos 50.70; degraus_y_plano 17 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr0.6/N3 | liso | pigmento | furos 17.06 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 41.10; km_max_plano 44.40; degraus_y_plano 24; degraus_x_plano 4 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 41.10; km_max_plano 44.90; degraus_y_plano 24; degraus_x_plano 4 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 36.40; km_max_plano 56.90; degraus_y_plano 23; degraus_x_plano 6 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 36.40; km_max_plano 57.60; degraus_y_plano 23; degraus_x_plano 6 |
| ExpressOil/Round/Express Oil | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N1 | padrao | velha | degraus_y_plano 1 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 4 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 14; degraus_x_plano 36 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N1 | padrao | pigmento | degraus_y_plano 1 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N1 | liso | velha | degraus_y_plano 14; degraus_x_plano 36 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N1 | liso | pigmento | degraus_y_plano 1 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 41.50; km_max_plano 44.80; furos 65.86; degraus_y_plano 22; degraus_x_plano 8 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N3 | padrao | pigmento | furos 48.67 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 41.50; km_max_plano 44.80; furos 65.86; degraus_y_plano 21; degraus_x_plano 8 |
| ExpressOil/Round/Express Oil | P600/W1/pr0.6/N3 | liso | pigmento | furos 48.67 |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 39.80; km_max_plano 42.40; degraus_y_plano 28; degraus_x_plano 12 |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N1 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N1 | liso | velha | km_p99_plano 39.80; km_max_plano 42.40; degraus_y_plano 28; degraus_x_plano 12 |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N1 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 28.10; km_max_plano 49.20; degraus_y_plano 26 |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N3 | liso | velha | km_p99_plano 28.10; km_max_plano 49.20; degraus_y_plano 26 |
| ExpressOil/Round/Express Oil | P600/W1/pr1/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 6 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 6 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.70; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.70; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.60; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.60; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 19 |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 23.80; km_max_plano 27.40; degraus_y_plano 19 |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N1 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.50; degraus_y_plano 15 |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.50; degraus_y_plano 15 |
| ExpressOil/Round/Express Oil | P2000/W0/pr1/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 6; degraus_x_plano 3 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 6; degraus_x_plano 3 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 18; degraus_x_plano 3 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 18; degraus_x_plano 3 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 24.40; km_max_plano 27.40; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 24.40; km_max_plano 27.40; degraus_y_plano 18 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.70; degraus_y_plano 16 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.70; degraus_y_plano 16 |
| ExpressOil/Round/Express Oil | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 6; degraus_x_plano 7 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 5; degraus_x_plano 6 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 15; degraus_x_plano 18 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N1 | liso | velha | degraus_y_plano 15; degraus_x_plano 17 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 36.80; km_max_plano 42.20; furos 20.49; degraus_y_plano 18; degraus_x_plano 6 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N3 | padrao | pigmento | furos 24.58 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 36.90; km_max_plano 42.60; furos 20.49; degraus_y_plano 17; degraus_x_plano 6 |
| ExpressOil/Round/Express Oil | P2000/W1/pr0.6/N3 | liso | pigmento | furos 24.58 |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 35.20; km_max_plano 44.30; degraus_y_plano 28; degraus_x_plano 21 |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 35.20; km_max_plano 44.90; degraus_y_plano 28; degraus_x_plano 21 |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N1 | liso | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 29.50; km_max_plano 50.00; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 29.50; km_max_plano 50.00; degraus_y_plano 22 |
| ExpressOil/Round/Express Oil | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N1 | padrao | velha | manchas_azul_plano 2.31; km_p99_plano 23.40; km_max_plano 28.20; furos 42.60; degraus_y_plano 11; degraus_x_plano 77 |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N1 | padrao | pigmento | furos 12.66 |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N1 | liso | velha | manchas_azul_plano 2.00; km_p99_plano 23.40; km_max_plano 26.90; furos 28.78; degraus_y_plano 10; degraus_x_plano 106 |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N1 | liso | pigmento | furos 5.47 |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 27.00; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.60; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Dabber/Dabber | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Dabber/Dabber | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0/pr1/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Dabber/Dabber | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 17.90; km_max_plano 25.10; degraus_y_plano 8 |
| Oil/Dabber/Dabber | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0/pr1/N3 | liso | velha | km_p99_plano 17.90; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Dabber/Dabber | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N1 | padrao | velha | degraus_y_plano 4; degraus_x_plano 30 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N1 | padrao | pigmento | furos 98.83 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N1 | liso | velha | furos 99.97; degraus_y_plano 8; degraus_x_plano 41 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N1 | liso | pigmento | furos 94.22; degraus_y_plano 1 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 27.70; km_max_plano 32.00; furos 64.38; degraus_y_plano 13; degraus_x_plano 46 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N3 | padrao | pigmento | furos 12.92 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 29.20; km_max_plano 34.20; furos 53.31; degraus_y_plano 20; degraus_x_plano 75 |
| Oil/Dabber/Dabber | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 9.17 |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 25.70; km_max_plano 39.20; degraus_y_plano 10; degraus_x_plano 69 |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N1 | padrao | pigmento | furos 0.39 |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 24.10; km_max_plano 38.80; furos 0.10; degraus_y_plano 14; degraus_x_plano 83 |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 20.40; km_max_plano 30.00; degraus_y_plano 12 |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 33.50; degraus_y_plano 12 |
| Oil/Dabber/Dabber | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N1 | liso | velha | degraus_x_plano 3 |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N3 | padrao | velha | furos 100.00; degraus_x_plano 4 |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N3 | liso | velha | furos 100.00; degraus_x_plano 11 |
| Oil/Dabber/Dabber | P40/W1/pr0.6/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P40/W1/pr1/N1 | padrao | velha | km_p99_plano 21.90; km_max_plano 21.90; degraus_y_plano 7; degraus_x_plano 41 |
| Oil/Dabber/Dabber | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Dabber/Dabber | P40/W1/pr1/N1 | liso | velha | km_p99_plano 19.90; degraus_y_plano 10; degraus_x_plano 52 |
| Oil/Dabber/Dabber | P40/W1/pr1/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Dabber/Dabber | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 24.90; km_max_plano 35.40; degraus_y_plano 11; degraus_x_plano 54 |
| Oil/Dabber/Dabber | P40/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P40/W1/pr1/N3 | liso | velha | km_p99_plano 24.30; km_max_plano 34.50; degraus_y_plano 16; degraus_x_plano 69 |
| Oil/Dabber/Dabber | P40/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N1 | padrao | velha | manchas_azul_plano 2.31; km_p99_plano 23.40; km_max_plano 28.20; furos 42.60; degraus_y_plano 11; degraus_x_plano 77 |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N1 | padrao | pigmento | furos 12.66 |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N1 | liso | velha | manchas_azul_plano 2.00; km_p99_plano 23.40; km_max_plano 26.90; furos 28.78; degraus_y_plano 10; degraus_x_plano 106 |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N1 | liso | pigmento | furos 5.47 |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 27.00; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.60; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Dabber/Dabber | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Dabber/Dabber | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0/pr1/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Dabber/Dabber | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 17.90; km_max_plano 25.10; degraus_y_plano 8 |
| Oil/Dabber/Dabber | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0/pr1/N3 | liso | velha | km_p99_plano 17.90; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Dabber/Dabber | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N1 | padrao | velha | manchas_azul_plano 2.19; km_p99_plano 26.20; km_max_plano 32.00; furos 70.18; degraus_y_plano 8; degraus_x_plano 73 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N1 | padrao | pigmento | furos 22.55 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N1 | liso | velha | manchas_azul_plano 3.15; km_p99_plano 26.70; km_max_plano 30.60; furos 58.15; degraus_y_plano 7; degraus_x_plano 98 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N1 | liso | pigmento | furos 12.94 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.80; km_max_plano 33.60; degraus_y_plano 10; degraus_x_plano 35 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 34.50; degraus_y_plano 12; degraus_x_plano 45 |
| Oil/Dabber/Dabber | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 35.90; furos 0.03; degraus_y_plano 13; degraus_x_plano 83 |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 37.60; degraus_y_plano 12; degraus_x_plano 79 |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 19.40; km_max_plano 34.70; degraus_y_plano 13; degraus_x_plano 6 |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 19.40; km_max_plano 33.60; degraus_y_plano 13; degraus_x_plano 5 |
| Oil/Dabber/Dabber | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N1 | padrao | velha | manchas_azul_plano 3.54; km_p99_plano 29.40; km_max_plano 34.50; furos 92.45; degraus_y_plano 8; degraus_x_plano 75 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N1 | padrao | pigmento | furos 53.78 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 28.70; km_max_plano 32.20; furos 89.32; degraus_y_plano 10; degraus_x_plano 86 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N1 | liso | pigmento | furos 36.85; degraus_y_plano 2 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 34.50; furos 0.23; degraus_y_plano 13; degraus_x_plano 40 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N3 | padrao | pigmento | furos 0.18 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 37.10; furos 0.03; degraus_y_plano 18; degraus_x_plano 55 |
| Oil/Dabber/Dabber | P600/W1/pr0.6/N3 | liso | pigmento | furos 0.03 |
| Oil/Dabber/Dabber | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 34.60; degraus_y_plano 12; degraus_x_plano 70 |
| Oil/Dabber/Dabber | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W1/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 38.80; furos 0.03; degraus_y_plano 14; degraus_x_plano 56 |
| Oil/Dabber/Dabber | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 19.20; km_max_plano 52.00; degraus_y_plano 10 |
| Oil/Dabber/Dabber | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P600/W1/pr1/N3 | liso | velha | km_p99_plano 19.10; km_max_plano 33.30; degraus_y_plano 9 |
| Oil/Dabber/Dabber | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N1 | padrao | velha | manchas_azul_plano 2.31; km_p99_plano 23.40; km_max_plano 28.20; furos 42.60; degraus_y_plano 11; degraus_x_plano 77 |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N1 | padrao | pigmento | furos 12.66 |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N1 | liso | velha | manchas_azul_plano 2.00; km_p99_plano 23.40; km_max_plano 26.90; furos 28.78; degraus_y_plano 10; degraus_x_plano 106 |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N1 | liso | pigmento | furos 5.47 |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 27.00; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 26.60; degraus_y_plano 12; degraus_x_plano 15 |
| Oil/Dabber/Dabber | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Dabber/Dabber | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Dabber/Dabber | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 17.90; km_max_plano 25.10; degraus_y_plano 8 |
| Oil/Dabber/Dabber | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 17.90; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Dabber/Dabber | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N1 | padrao | velha | manchas_azul_plano 3.09; km_p99_plano 23.40; km_max_plano 27.40; furos 48.02; degraus_y_plano 9; degraus_x_plano 73 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N1 | padrao | pigmento | furos 14.53; degraus_y_plano 1 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N1 | liso | velha | manchas_azul_plano 2.61; km_p99_plano 24.20; km_max_plano 27.40; furos 33.46; degraus_y_plano 10; degraus_x_plano 108 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N1 | liso | pigmento | furos 7.32 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 24.70; degraus_y_plano 12; degraus_x_plano 22 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 25.80; degraus_y_plano 11; degraus_x_plano 17 |
| Oil/Dabber/Dabber | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 9 |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 19.00; km_max_plano 24.50; degraus_y_plano 10 |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 26.90; degraus_y_plano 6 |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 23.40; degraus_y_plano 6 |
| Oil/Dabber/Dabber | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N1 | padrao | velha | manchas_azul_plano 3.20; km_p99_plano 29.10; km_max_plano 34.70; furos 70.31; degraus_y_plano 10; degraus_x_plano 86 |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N1 | padrao | pigmento | furos 24.87 |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N1 | liso | velha | manchas_azul_plano 2.75; km_p99_plano 29.20; km_max_plano 33.00; furos 57.53; degraus_y_plano 13; degraus_x_plano 110 |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N1 | liso | pigmento | furos 14.61 |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 34.20; degraus_y_plano 10; degraus_x_plano 32 |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 36.20; degraus_y_plano 16; degraus_x_plano 54 |
| Oil/Dabber/Dabber | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 20.70; km_max_plano 33.90; furos 0.03; degraus_y_plano 14; degraus_x_plano 108 |
| Oil/Dabber/Dabber | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 20.70; km_max_plano 38.00; degraus_y_plano 15; degraus_x_plano 107 |
| Oil/Dabber/Dabber | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 19.40; km_max_plano 40.40; degraus_y_plano 13 |
| Oil/Dabber/Dabber | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 19.20; km_max_plano 53.20; degraus_y_plano 14 |
| Oil/Dabber/Dabber | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.2/N3 | liso | pigmento | furos 99.97 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 7; degraus_x_plano 23 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 25.40; furos 69.04; degraus_y_plano 6; degraus_x_plano 28 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N1 | liso | pigmento | furos 19.84 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 27.20; furos 1.85; degraus_y_plano 11; degraus_x_plano 73 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N3 | padrao | pigmento | furos 0.96 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.50; furos 0.31; degraus_y_plano 16; degraus_x_plano 88 |
| Oil/Dabber/Dabber 4 | P40/W0/pr0.6/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 26.50; degraus_y_plano 17; degraus_x_plano 20 |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N1 | liso | velha | km_p99_plano 21.20; km_max_plano 25.80; furos 0.18; degraus_y_plano 9; degraus_x_plano 20 |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N1 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.50; furos 0.65; degraus_y_plano 7 |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N3 | padrao | pigmento | furos 0.65 |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 23.40; furos 0.16; degraus_y_plano 8 |
| Oil/Dabber/Dabber 4 | P40/W0/pr1/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N1 | padrao | velha | degraus_x_plano 4 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N1 | liso | velha | degraus_x_plano 6 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N1 | liso | pigmento | furos 97.29 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 24.70; km_max_plano 27.70; furos 92.76; degraus_y_plano 11; degraus_x_plano 37 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N3 | padrao | pigmento | furos 31.54 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.80; km_max_plano 27.10; furos 89.74; degraus_y_plano 9; degraus_x_plano 43 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 18.46 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N1 | padrao | velha | manchas_azul_plano 1.36; km_p99_plano 27.20; km_max_plano 32.00; degraus_y_plano 10; degraus_x_plano 51 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 26.30; km_max_plano 33.20; degraus_y_plano 9; degraus_x_plano 49 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N1 | liso | pigmento | furos 0.60 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 29.50; degraus_y_plano 10; degraus_x_plano 61 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 21.60; km_max_plano 28.00; degraus_y_plano 15; degraus_x_plano 57 |
| Oil/Dabber/Dabber 4 | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P40/W1/pr0.6/N3 | liso | pigmento | furos 99.95 |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 8; degraus_x_plano 13 |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 6; degraus_x_plano 11 |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N1 | liso | pigmento | degraus_y_plano 5 |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 27.70; km_max_plano 31.30; degraus_y_plano 11; degraus_x_plano 49 |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N3 | liso | velha | km_p99_plano 26.80; km_max_plano 30.50; degraus_y_plano 12; degraus_x_plano 39 |
| Oil/Dabber/Dabber 4 | P40/W1/pr1/N3 | liso | pigmento | furos 0.44 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.2/N3 | liso | pigmento | furos 99.97 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 7; degraus_x_plano 23 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 25.40; furos 69.04; degraus_y_plano 6; degraus_x_plano 28 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N1 | liso | pigmento | furos 19.84 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 27.20; furos 1.85; degraus_y_plano 11; degraus_x_plano 73 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N3 | padrao | pigmento | furos 0.96 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.50; furos 0.31; degraus_y_plano 16; degraus_x_plano 88 |
| Oil/Dabber/Dabber 4 | P600/W0/pr0.6/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 26.50; degraus_y_plano 17; degraus_x_plano 20 |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N1 | liso | velha | km_p99_plano 21.20; km_max_plano 25.80; furos 0.18; degraus_y_plano 9; degraus_x_plano 20 |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N1 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.50; furos 0.65; degraus_y_plano 7 |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N3 | padrao | pigmento | furos 0.65 |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 23.40; furos 0.16; degraus_y_plano 8 |
| Oil/Dabber/Dabber 4 | P600/W0/pr1/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 99.97 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 24.70; degraus_y_plano 8; degraus_x_plano 23 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N1 | padrao | pigmento | furos 42.16 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.60; km_max_plano 27.80; furos 87.21; degraus_y_plano 6; degraus_x_plano 31 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N1 | liso | pigmento | furos 26.69 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.90; km_max_plano 29.60; furos 5.23; degraus_y_plano 12; degraus_x_plano 51 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N3 | padrao | pigmento | furos 0.89 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.90; km_max_plano 29.30; furos 1.61; degraus_y_plano 12; degraus_x_plano 67 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr0.6/N3 | liso | pigmento | furos 0.05 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 30.60; degraus_y_plano 9; degraus_x_plano 38 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N1 | padrao | pigmento | furos 0.68 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 21.90; km_max_plano 31.90; furos 0.13; degraus_y_plano 8; degraus_x_plano 43 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 24.60; degraus_y_plano 9; degraus_x_plano 77 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.60; km_max_plano 27.30; degraus_y_plano 11; degraus_x_plano 82 |
| Oil/Dabber/Dabber 4 | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 22.30; km_max_plano 22.50; degraus_y_plano 7; degraus_x_plano 13 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 24.40; km_max_plano 27.20; furos 97.60; degraus_y_plano 7; degraus_x_plano 22 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N1 | liso | pigmento | furos 47.66 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N3 | padrao | velha | manchas_azul_plano 3.68; km_p99_plano 25.50; km_max_plano 30.50; furos 15.47; degraus_y_plano 9; degraus_x_plano 41 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N3 | padrao | pigmento | furos 3.46 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N3 | liso | velha | manchas_azul_plano 1.13; km_p99_plano 25.30; km_max_plano 31.80; furos 5.91; degraus_y_plano 11; degraus_x_plano 60 |
| Oil/Dabber/Dabber 4 | P600/W1/pr0.6/N3 | liso | pigmento | furos 0.96 |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 22.50; km_max_plano 30.30; degraus_y_plano 11; degraus_x_plano 42 |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N1 | liso | velha | km_p99_plano 22.50; km_max_plano 34.00; furos 0.21; degraus_y_plano 6; degraus_x_plano 46 |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.50; degraus_y_plano 6; degraus_x_plano 31 |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 26.60; degraus_y_plano 8; degraus_x_plano 29 |
| Oil/Dabber/Dabber 4 | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.2/N3 | liso | pigmento | furos 99.97 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 7; degraus_x_plano 23 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 25.40; furos 69.04; degraus_y_plano 6; degraus_x_plano 28 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N1 | liso | pigmento | furos 19.84 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 21.60; km_max_plano 27.20; furos 1.85; degraus_y_plano 11; degraus_x_plano 73 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N3 | padrao | pigmento | furos 0.96 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 26.50; furos 0.31; degraus_y_plano 16; degraus_x_plano 88 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr0.6/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 26.50; degraus_y_plano 17; degraus_x_plano 20 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 21.20; km_max_plano 25.80; furos 0.18; degraus_y_plano 9; degraus_x_plano 20 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N1 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 25.50; furos 0.65; degraus_y_plano 7 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N3 | padrao | pigmento | furos 0.65 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 23.40; furos 0.16; degraus_y_plano 8 |
| Oil/Dabber/Dabber 4 | P2000/W0/pr1/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.2/N3 | liso | pigmento | furos 99.97 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.20; degraus_y_plano 7; degraus_x_plano 21 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.50; furos 73.91; degraus_y_plano 6; degraus_x_plano 28 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N1 | liso | pigmento | furos 21.95; degraus_y_plano 1 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 22.50; km_max_plano 26.90; furos 2.08; degraus_y_plano 12; degraus_x_plano 81 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N3 | padrao | pigmento | furos 1.04 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 27.40; furos 0.31; degraus_y_plano 14; degraus_x_plano 83 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr0.6/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 26.50; degraus_y_plano 15; degraus_x_plano 18 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 26.50; furos 0.23; degraus_y_plano 11; degraus_x_plano 19 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N1 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 24.30; furos 0.65; degraus_y_plano 8 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N3 | padrao | pigmento | furos 0.65 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 23.40; furos 0.16; degraus_y_plano 7 |
| Oil/Dabber/Dabber 4 | P2000/W0.5/pr1/N3 | liso | pigmento | furos 0.16 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 24.60; km_max_plano 27.40; degraus_y_plano 6; degraus_x_plano 22 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N1 | padrao | pigmento | furos 43.70 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 28.10; km_max_plano 29.40; furos 86.82; degraus_y_plano 7; degraus_x_plano 25 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N1 | liso | pigmento | furos 27.71 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 30.00; furos 5.49; degraus_y_plano 11; degraus_x_plano 51 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N3 | padrao | pigmento | furos 0.99 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 30.00; furos 1.72; degraus_y_plano 13; degraus_x_plano 66 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr0.6/N3 | liso | pigmento | furos 0.08 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 31.90; degraus_y_plano 9; degraus_x_plano 55 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N1 | padrao | pigmento | furos 0.73 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 28.90; furos 0.08; degraus_y_plano 13; degraus_x_plano 59 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 19.10; km_max_plano 27.20; degraus_y_plano 9; degraus_x_plano 35 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 25.30; degraus_y_plano 9; degraus_x_plano 36 |
| Oil/Dabber/Dabber 4 | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N1 | padrao | velha | km_p99_plano 20.90; km_max_plano 21.50; degraus_x_plano 13 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N1 | liso | velha | degraus_y_plano 3; degraus_x_plano 120 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N3 | padrao | velha | manchas_azul_plano 2.65; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 5; degraus_x_plano 36 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N3 | liso | velha | km_p99_plano 24.80; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 127 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 3; degraus_x_plano 38 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 2; degraus_x_plano 118 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 5 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 26.60; degraus_y_plano 5 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 25.90; degraus_y_plano 5; degraus_x_plano 17 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N1 | liso | velha | km_p99_plano 17.20; km_max_plano 26.00; degraus_y_plano 1; degraus_x_plano 9 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 24.60 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 24.70 |
| Oil/Knife/Knife Smooth 3 | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N1 | padrao | velha | degraus_x_plano 6 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N1 | liso | velha | degraus_y_plano 1; degraus_x_plano 3 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N3 | padrao | velha | degraus_y_plano 7; degraus_x_plano 37 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N3 | liso | velha | furos 99.82; degraus_y_plano 14; degraus_x_plano 105 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 94.84 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 48.80; km_max_plano 51.20; degraus_y_plano 2; degraus_x_plano 68 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 12; degraus_x_plano 153 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 37.30; km_max_plano 51.60; degraus_y_plano 12; degraus_x_plano 57 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 40.60; km_max_plano 51.40; furos 7.29; degraus_y_plano 13; degraus_x_plano 142 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 2.66 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N1 | padrao | velha | manchas_azul_plano 1.48; km_p99_plano 44.20; km_max_plano 52.60; degraus_y_plano 3; degraus_x_plano 72 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 46.90; km_max_plano 61.30; degraus_y_plano 15; degraus_x_plano 161 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 28.90; km_max_plano 50.20; degraus_y_plano 14; degraus_x_plano 23 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 27.80; km_max_plano 57.40; furos 0.42; degraus_y_plano 7; degraus_x_plano 39 |
| Oil/Knife/Knife Smooth 3 | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 3; degraus_x_plano 5 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N1 | liso | velha | degraus_y_plano 4 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N3 | padrao | velha | degraus_y_plano 11; degraus_x_plano 59 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N3 | padrao | pigmento | degraus_y_plano 6 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N3 | liso | velha | degraus_y_plano 12; degraus_x_plano 118 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr0.6/N3 | liso | pigmento | furos 99.82 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 7; degraus_x_plano 50 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 13; degraus_x_plano 116 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 44.10; km_max_plano 50.90; degraus_y_plano 14; degraus_x_plano 78 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N3 | liso | velha | km_p99_plano 40.20; km_max_plano 45.80; degraus_y_plano 21; degraus_x_plano 137 |
| Oil/Knife/Knife Smooth 3 | P40/W1/pr1/N3 | liso | pigmento | furos 0.03 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N1 | padrao | velha | km_p99_plano 20.90; km_max_plano 21.50; degraus_x_plano 13 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N1 | liso | velha | degraus_y_plano 3; degraus_x_plano 120 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N3 | padrao | velha | manchas_azul_plano 2.65; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 5; degraus_x_plano 36 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N3 | liso | velha | km_p99_plano 24.80; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 127 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 3; degraus_x_plano 38 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 2; degraus_x_plano 118 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 5 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 26.60; degraus_y_plano 5 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 25.90; degraus_y_plano 5; degraus_x_plano 17 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N1 | liso | velha | km_p99_plano 17.20; km_max_plano 26.00; degraus_y_plano 1; degraus_x_plano 9 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 24.60 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 24.70 |
| Oil/Knife/Knife Smooth 3 | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N1 | padrao | velha | degraus_y_plano 1; degraus_x_plano 19 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 4; degraus_x_plano 101 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 81.74 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N3 | padrao | velha | manchas_azul_plano 1.83; km_p99_plano 33.60; km_max_plano 38.60; degraus_y_plano 7; degraus_x_plano 61 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 39.60; km_max_plano 41.20; furos 59.74; degraus_y_plano 12; degraus_x_plano 140 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 24.87 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 43.10; km_max_plano 50.30; degraus_y_plano 6; degraus_x_plano 93 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 43.90; km_max_plano 50.50; furos 25.68; degraus_y_plano 12; degraus_x_plano 166 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N1 | liso | pigmento | furos 15.62 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 36.60; km_max_plano 54.60; degraus_y_plano 13; degraus_x_plano 29 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 34.80; km_max_plano 63.60; furos 0.34; degraus_y_plano 22; degraus_x_plano 40 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 44.90; km_max_plano 56.40; degraus_y_plano 4; degraus_x_plano 73 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 42.00; km_max_plano 65.90; furos 0.52; degraus_y_plano 21; degraus_x_plano 70 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 30.70; km_max_plano 59.70; degraus_y_plano 8; degraus_x_plano 6 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 32.90; km_max_plano 64.60; furos 0.10; degraus_y_plano 15; degraus_x_plano 9 |
| Oil/Knife/Knife Smooth 3 | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N1 | padrao | velha | degraus_y_plano 2; degraus_x_plano 38 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N1 | liso | velha | degraus_y_plano 5; degraus_x_plano 94 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N1 | liso | pigmento | furos 95.99 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N3 | padrao | velha | km_p99_plano 42.50; km_max_plano 48.40; degraus_y_plano 8; degraus_x_plano 71 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N3 | liso | velha | km_p99_plano 42.80; km_max_plano 52.40; furos 95.10; degraus_y_plano 15; degraus_x_plano 153 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.2/N3 | liso | pigmento | furos 29.14 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N1 | padrao | velha | manchas_azul_plano 2.12; km_p99_plano 44.50; km_max_plano 49.90; degraus_y_plano 6; degraus_x_plano 75 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 46.90; km_max_plano 54.50; degraus_y_plano 11; degraus_x_plano 163 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N1 | liso | pigmento | furos 26.54 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 28.90; km_max_plano 47.10; degraus_y_plano 13; degraus_x_plano 32 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 26.40; km_max_plano 53.10; furos 0.57; degraus_y_plano 9; degraus_x_plano 33 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr0.6/N3 | liso | pigmento | furos 0.18 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 38.80; km_max_plano 51.40; degraus_y_plano 8; degraus_x_plano 51 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N1 | liso | velha | km_p99_plano 35.20; km_max_plano 58.00; degraus_y_plano 7; degraus_x_plano 87 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N1 | liso | pigmento | furos 0.42 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 25.90; km_max_plano 44.90; degraus_y_plano 7 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N3 | liso | velha | km_p99_plano 25.30; km_max_plano 50.60; furos 0.08; degraus_x_plano 4 |
| Oil/Knife/Knife Smooth 3 | P600/W1/pr1/N3 | liso | pigmento | furos 0.03 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N1 | padrao | velha | km_p99_plano 20.90; km_max_plano 21.50; degraus_x_plano 13 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N1 | liso | velha | degraus_y_plano 3; degraus_x_plano 120 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N3 | padrao | velha | manchas_azul_plano 2.65; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 5; degraus_x_plano 36 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N3 | liso | velha | km_p99_plano 24.80; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 127 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 3; degraus_x_plano 38 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 2; degraus_x_plano 118 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 23.40; degraus_y_plano 12; degraus_x_plano 5 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 26.60; degraus_y_plano 5 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 25.90; degraus_y_plano 5; degraus_x_plano 17 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 17.20; km_max_plano 26.00; degraus_y_plano 1; degraus_x_plano 9 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 18.00; km_max_plano 24.60 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.00; km_max_plano 24.70 |
| Oil/Knife/Knife Smooth 3 | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N1 | padrao | velha | km_p99_plano 20.70; km_max_plano 20.70; degraus_x_plano 14 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N1 | liso | velha | degraus_y_plano 3; degraus_x_plano 113 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N3 | padrao | velha | manchas_azul_plano 3.28; km_p99_plano 23.40; km_max_plano 27.00; degraus_y_plano 5; degraus_x_plano 34 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 25.20; km_max_plano 26.90; degraus_y_plano 12; degraus_x_plano 123 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 22.80; km_max_plano 27.00; degraus_y_plano 1; degraus_x_plano 40 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 23.40; km_max_plano 25.80; degraus_y_plano 3; degraus_x_plano 121 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 20.60; km_max_plano 23.40; degraus_y_plano 14; degraus_x_plano 8 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 25.60; degraus_y_plano 6 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 24.60; degraus_y_plano 4; degraus_x_plano 20 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 17.20; km_max_plano 26.50; degraus_y_plano 1; degraus_x_plano 9 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 17.90; km_max_plano 25.20 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 17.90; km_max_plano 25.60 |
| Oil/Knife/Knife Smooth 3 | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N1 | padrao | velha | degraus_y_plano 1; degraus_x_plano 48 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 5; degraus_x_plano 136 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N1 | liso | pigmento | furos 84.22 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N3 | padrao | velha | manchas_azul_plano 2.74; km_p99_plano 37.80; km_max_plano 45.10; degraus_y_plano 8; degraus_x_plano 68 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N3 | liso | velha | km_p99_plano 44.00; km_max_plano 48.50; furos 60.55; degraus_y_plano 11; degraus_x_plano 156 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.2/N3 | liso | pigmento | furos 25.16 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N1 | padrao | velha | manchas_azul_plano 1.02; km_p99_plano 42.60; km_max_plano 53.50; degraus_y_plano 6; degraus_x_plano 90 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 42.70; km_max_plano 58.80; furos 26.90; degraus_y_plano 11; degraus_x_plano 158 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N1 | liso | pigmento | furos 16.59 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 30.30; km_max_plano 55.20; degraus_y_plano 15; degraus_x_plano 28 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 29.20; km_max_plano 61.10; furos 0.36; degraus_y_plano 16; degraus_x_plano 41 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr0.6/N3 | liso | pigmento | furos 0.03 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 38.60; km_max_plano 59.00; degraus_y_plano 7; degraus_x_plano 64 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 36.20; km_max_plano 60.20; furos 0.65; degraus_y_plano 19; degraus_x_plano 69 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 25.10; km_max_plano 51.40; degraus_y_plano 6; degraus_x_plano 8 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 28.30; km_max_plano 66.90; furos 0.13; degraus_y_plano 9; degraus_x_plano 8 |
| Oil/Knife/Knife Smooth 3 | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 27.00; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 27.00; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P40/W0/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.00; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.70; km_max_plano 26.00; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 23.90; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.80; km_max_plano 23.90; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 18.80; km_max_plano 29.00; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr1/N1 | liso | velha | km_p99_plano 18.80; km_max_plano 29.00; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N3 | padrao | velha | furos 100.00; degraus_y_plano 6; degraus_x_plano 39 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 6; degraus_x_plano 40 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 34.30; km_max_plano 36.00; furos 58.85; degraus_y_plano 12; degraus_x_plano 6 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N1 | padrao | pigmento | furos 52.92 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 34.30; km_max_plano 36.00; furos 58.85; degraus_y_plano 12; degraus_x_plano 6 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N1 | liso | pigmento | furos 52.92 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 23.10; km_max_plano 40.00; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 23.10; km_max_plano 40.10; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 26.30; km_max_plano 39.50; degraus_y_plano 9 |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 26.30; km_max_plano 39.50; degraus_y_plano 9 |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.30; degraus_y_plano 16 |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 19.70; km_max_plano 26.30; degraus_y_plano 16 |
| Oil/Knife/Knife Oily | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N3 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N3 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N3 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W1/pr0.2/N3 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N1 | padrao | velha | degraus_y_plano 6 |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N1 | liso | velha | degraus_y_plano 6 |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N3 | padrao | velha | furos 100.00; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N3 | padrao | pigmento | furos 62.40 |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N3 | liso | velha | furos 100.00; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P40/W1/pr0.6/N3 | liso | pigmento | furos 62.40 |
| Oil/Knife/Knife Oily | P40/W1/pr1/N1 | padrao | velha | km_p99_plano 26.20; km_max_plano 26.90; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Oily | P40/W1/pr1/N1 | liso | velha | km_p99_plano 26.20; km_max_plano 26.20; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P40/W1/pr1/N1 | liso | pigmento | degraus_y_plano 2 |
| Oil/Knife/Knife Oily | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 25.00; km_max_plano 37.60; degraus_y_plano 11 |
| Oil/Knife/Knife Oily | P40/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P40/W1/pr1/N3 | liso | velha | km_p99_plano 24.90; km_max_plano 37.60; degraus_y_plano 11 |
| Oil/Knife/Knife Oily | P40/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 27.00; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 27.00; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P600/W0/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.00; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.70; km_max_plano 26.00; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 23.90; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.80; km_max_plano 23.90; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 18.80; km_max_plano 29.00; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr1/N1 | liso | velha | km_p99_plano 18.80; km_max_plano 29.00; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 26.00; furos 35.81; degraus_y_plano 11; degraus_x_plano 17 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N3 | padrao | pigmento | furos 0.21 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 26.00; furos 35.81; degraus_y_plano 11; degraus_x_plano 17 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 0.18 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 26.70; km_max_plano 41.90; degraus_y_plano 15; degraus_x_plano 14 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 26.60; km_max_plano 42.10; degraus_y_plano 15; degraus_x_plano 14 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 22.40; km_max_plano 42.20; degraus_y_plano 10; degraus_x_plano 6 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 42.60; degraus_y_plano 10; degraus_x_plano 6 |
| Oil/Knife/Knife Oily | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 30.00; km_max_plano 44.80; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 30.30; km_max_plano 44.80; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 23.40; degraus_y_plano 17 |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 17 |
| Oil/Knife/Knife Oily | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N1 | padrao | velha | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N1 | liso | velha | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 23.60; furos 67.63; degraus_y_plano 12; degraus_x_plano 16 |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N3 | padrao | pigmento | furos 51.48 |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 23.50; furos 67.63; degraus_y_plano 12; degraus_x_plano 16 |
| Oil/Knife/Knife Oily | P600/W1/pr0.2/N3 | liso | pigmento | furos 51.48 |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 23.70; km_max_plano 39.70; degraus_y_plano 12; degraus_x_plano 4 |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 23.70; km_max_plano 39.70; degraus_y_plano 12; degraus_x_plano 3 |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 20.60; km_max_plano 38.10; degraus_y_plano 10 |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 38.10; degraus_y_plano 10 |
| Oil/Knife/Knife Oily | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 23.10; km_max_plano 38.40; degraus_y_plano 9 |
| Oil/Knife/Knife Oily | P600/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Oily | P600/W1/pr1/N1 | liso | velha | km_p99_plano 23.10; km_max_plano 38.40; degraus_y_plano 9 |
| Oil/Knife/Knife Oily | P600/W1/pr1/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Oily | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P600/W1/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 27.00; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N3 | liso | velha | km_p99_plano 23.40; km_max_plano 27.00; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N1 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.00; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N1 | liso | velha | km_p99_plano 19.70; km_max_plano 26.00; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 23.90; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 18.80; km_max_plano 23.90; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 18.80; km_max_plano 29.00; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 18.80; km_max_plano 29.00; degraus_y_plano 13 |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 3 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 25.50; km_max_plano 26.90; degraus_y_plano 13; degraus_x_plano 7 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 25.50; km_max_plano 26.90; degraus_y_plano 13; degraus_x_plano 7 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 20.60; km_max_plano 27.40; degraus_y_plano 15 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N1 | liso | velha | km_p99_plano 20.60; km_max_plano 27.40; degraus_y_plano 15 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 19.00; km_max_plano 26.00; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 19.00; km_max_plano 26.00; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 18.80; km_max_plano 28.20; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 18.80; km_max_plano 28.20; degraus_y_plano 14 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.50; km_max_plano 23.40; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N1 | padrao | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N1 | padrao | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N1 | liso | velha | furos 100.00; degraus_y_plano 2 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N1 | liso | pigmento | furos 100.00 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N3 | padrao | velha | km_p99_plano 25.20; km_max_plano 30.10; furos 42.03; degraus_y_plano 13; degraus_x_plano 14 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N3 | padrao | pigmento | furos 0.76 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N3 | liso | velha | km_p99_plano 25.20; km_max_plano 30.10; furos 42.03; degraus_y_plano 13; degraus_x_plano 14 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.2/N3 | liso | pigmento | furos 0.76 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N1 | padrao | velha | km_p99_plano 23.70; km_max_plano 45.10; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 23.70; km_max_plano 45.10; degraus_y_plano 14; degraus_x_plano 9 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 20.60; km_max_plano 39.90; degraus_y_plano 11 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 20.60; km_max_plano 39.90; degraus_y_plano 11 |
| Oil/Knife/Knife Oily | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 23.50; km_max_plano 45.70; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 23.60; km_max_plano 45.70; degraus_y_plano 12 |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 15 |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 23.40; degraus_y_plano 15 |
| Oil/Knife/Knife Oily | P2000/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N1 | padrao | velha | km_p99_plano 19.30; degraus_y_plano 2; degraus_x_plano 25 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N1 | liso | velha | degraus_y_plano 2; degraus_x_plano 32 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N3 | padrao | velha | km_p99_plano 24.50; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 61 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N3 | liso | velha | km_p99_plano 25.50; km_max_plano 27.40; degraus_y_plano 10; degraus_x_plano 126 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N1 | padrao | velha | manchas_azul_plano 4.00; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 80 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N1 | liso | velha | manchas_azul_plano 2.30; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 122 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.40; degraus_y_plano 13; degraus_x_plano 13 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N3 | liso | velha | km_p99_plano 19.70; km_max_plano 24.70; degraus_y_plano 10 |
| Oil/Knife/Knife Grainy | P40/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.80; degraus_y_plano 8; degraus_x_plano 91 |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 7; degraus_x_plano 106 |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.60; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P40/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N1 | padrao | velha | degraus_x_plano 3 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N1 | liso | velha | degraus_x_plano 6 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N3 | padrao | velha | degraus_y_plano 3; degraus_x_plano 11 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N3 | liso | velha | furos 100.00; degraus_y_plano 6; degraus_x_plano 41 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.2/N3 | liso | pigmento | furos 97.60 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N1 | padrao | velha | km_p99_plano 22.10; km_max_plano 22.10; degraus_y_plano 8; degraus_x_plano 29 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N1 | padrao | pigmento | degraus_y_plano 2 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N1 | liso | velha | degraus_y_plano 8; degraus_x_plano 74 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N1 | liso | pigmento | degraus_y_plano 2 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N3 | padrao | velha | manchas_azul_plano 1.19; km_p99_plano 31.80; km_max_plano 41.20; degraus_y_plano 13; degraus_x_plano 78 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 32.80; km_max_plano 44.60; furos 16.20; degraus_y_plano 13; degraus_x_plano 133 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr0.6/N3 | liso | pigmento | furos 3.75 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N1 | padrao | velha | km_p99_plano 31.20; km_max_plano 37.00; degraus_y_plano 10; degraus_x_plano 69 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N1 | liso | velha | km_p99_plano 32.80; km_max_plano 39.40; degraus_y_plano 11; degraus_x_plano 126 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 37.60; degraus_y_plano 13; degraus_x_plano 55 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N3 | liso | velha | km_p99_plano 22.50; km_max_plano 40.50; degraus_y_plano 10; degraus_x_plano 62 |
| Oil/Knife/Knife Grainy | P40/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N1 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N3 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N3 | liso | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.2/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N1 | padrao | velha | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N1 | liso | velha | degraus_x_plano 6 |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N3 | padrao | velha | degraus_y_plano 4; degraus_x_plano 42 |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N3 | liso | velha | degraus_y_plano 8; degraus_x_plano 64 |
| Oil/Knife/Knife Grainy | P40/W1/pr0.6/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N1 | padrao | velha | degraus_y_plano 3; degraus_x_plano 8 |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N1 | liso | velha | degraus_y_plano 2; degraus_x_plano 19 |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N1 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N3 | padrao | velha | km_p99_plano 22.30; km_max_plano 22.30; degraus_y_plano 12; degraus_x_plano 75 |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N3 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N3 | liso | velha | km_p99_plano 23.30; km_max_plano 23.30; degraus_y_plano 13; degraus_x_plano 77 |
| Oil/Knife/Knife Grainy | P40/W1/pr1/N3 | liso | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N1 | padrao | velha | km_p99_plano 19.30; degraus_y_plano 2; degraus_x_plano 25 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N1 | liso | velha | degraus_y_plano 2; degraus_x_plano 32 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N3 | padrao | velha | km_p99_plano 24.50; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 61 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N3 | liso | velha | km_p99_plano 25.50; km_max_plano 27.40; degraus_y_plano 10; degraus_x_plano 126 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N1 | padrao | velha | manchas_azul_plano 4.00; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 80 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N1 | liso | velha | manchas_azul_plano 2.30; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 122 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.40; degraus_y_plano 13; degraus_x_plano 13 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N3 | liso | velha | km_p99_plano 19.70; km_max_plano 24.70; degraus_y_plano 10 |
| Oil/Knife/Knife Grainy | P600/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.80; degraus_y_plano 8; degraus_x_plano 91 |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 7; degraus_x_plano 106 |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.60; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P600/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N1 | padrao | velha | degraus_y_plano 2; degraus_x_plano 20 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N1 | liso | velha | degraus_y_plano 1; degraus_x_plano 30 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N1 | liso | pigmento | furos 90.13 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 23.80; km_max_plano 25.90; degraus_y_plano 11; degraus_x_plano 62 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 24.10; km_max_plano 26.90; furos 74.77; degraus_y_plano 14; degraus_x_plano 113 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.2/N3 | liso | pigmento | furos 20.91 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N1 | padrao | velha | manchas_azul_plano 4.65; km_p99_plano 25.20; km_max_plano 31.30; degraus_y_plano 11; degraus_x_plano 75 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N1 | liso | velha | manchas_azul_plano 1.35; km_p99_plano 28.80; km_max_plano 34.00; degraus_y_plano 11; degraus_x_plano 139 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N1 | liso | pigmento | furos 12.58 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 25.50; km_max_plano 37.00; degraus_y_plano 10; degraus_x_plano 50 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 25.30; km_max_plano 32.60; degraus_y_plano 11; degraus_x_plano 33 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N1 | padrao | velha | km_p99_plano 27.70; km_max_plano 37.00; degraus_y_plano 8; degraus_x_plano 90 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N1 | liso | velha | km_p99_plano 27.60; km_max_plano 37.50; degraus_y_plano 15; degraus_x_plano 120 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N1 | liso | pigmento | furos 0.10 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N3 | padrao | velha | km_p99_plano 20.30; km_max_plano 31.00; degraus_y_plano 8; degraus_x_plano 25 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N3 | liso | velha | km_p99_plano 20.50; km_max_plano 28.90; degraus_y_plano 8; degraus_x_plano 29 |
| Oil/Knife/Knife Grainy | P600/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N1 | padrao | velha | degraus_y_plano 1; degraus_x_plano 18 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N1 | liso | velha | degraus_y_plano 1; degraus_x_plano 17 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N1 | liso | pigmento | furos 93.44 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N3 | padrao | velha | km_p99_plano 26.40; km_max_plano 28.00; degraus_y_plano 11; degraus_x_plano 55 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N3 | liso | velha | km_p99_plano 26.20; km_max_plano 26.20; furos 99.38; degraus_y_plano 16; degraus_x_plano 111 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.2/N3 | liso | pigmento | furos 36.67 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N1 | padrao | velha | km_p99_plano 34.50; km_max_plano 44.80; degraus_y_plano 12; degraus_x_plano 69 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N1 | padrao | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N1 | liso | velha | km_p99_plano 36.00; km_max_plano 44.60; degraus_y_plano 13; degraus_x_plano 123 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N1 | liso | pigmento | furos 23.44 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N3 | padrao | velha | km_p99_plano 23.40; km_max_plano 35.90; degraus_y_plano 14; degraus_x_plano 61 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N3 | liso | velha | km_p99_plano 22.10; km_max_plano 36.00; degraus_y_plano 9; degraus_x_plano 40 |
| Oil/Knife/Knife Grainy | P600/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N1 | padrao | velha | km_p99_plano 28.00; km_max_plano 40.30; degraus_y_plano 8; degraus_x_plano 70 |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N1 | liso | velha | km_p99_plano 26.80; km_max_plano 41.40; degraus_y_plano 12; degraus_x_plano 130 |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N1 | liso | pigmento | furos 0.96 |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 28.70; degraus_y_plano 8; degraus_x_plano 9 |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N3 | liso | velha | km_p99_plano 18.80; km_max_plano 28.60; degraus_y_plano 8; degraus_x_plano 9 |
| Oil/Knife/Knife Grainy | P600/W1/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N1 | padrao | velha | km_p99_plano 19.30; degraus_y_plano 2; degraus_x_plano 25 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N1 | liso | velha | degraus_y_plano 2; degraus_x_plano 32 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N3 | padrao | velha | km_p99_plano 24.50; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 61 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N3 | liso | velha | km_p99_plano 25.50; km_max_plano 27.40; degraus_y_plano 10; degraus_x_plano 126 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N1 | padrao | velha | manchas_azul_plano 4.00; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 80 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N1 | liso | velha | manchas_azul_plano 2.30; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 122 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.40; degraus_y_plano 13; degraus_x_plano 13 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N3 | liso | velha | km_p99_plano 19.70; km_max_plano 24.70; degraus_y_plano 10 |
| Oil/Knife/Knife Grainy | P2000/W0/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.80; degraus_y_plano 8; degraus_x_plano 91 |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 7; degraus_x_plano 106 |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 23.40; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N3 | liso | velha | km_p99_plano 18.70; km_max_plano 25.60; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P2000/W0/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N1 | padrao | velha | km_p99_plano 19.30; degraus_y_plano 3; degraus_x_plano 19 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N1 | liso | velha | degraus_y_plano 1; degraus_x_plano 26 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N1 | liso | pigmento | degraus_y_plano 1 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N3 | padrao | velha | km_p99_plano 24.40; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 61 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N3 | liso | velha | km_p99_plano 25.70; km_max_plano 27.40; degraus_y_plano 11; degraus_x_plano 126 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.2/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N1 | padrao | velha | manchas_azul_plano 3.10; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 10; degraus_x_plano 81 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N1 | liso | velha | manchas_azul_plano 1.25; km_p99_plano 23.40; km_max_plano 26.90; degraus_y_plano 8; degraus_x_plano 123 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N3 | padrao | velha | km_p99_plano 19.70; km_max_plano 26.60; degraus_y_plano 17; degraus_x_plano 21 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N3 | liso | velha | km_p99_plano 19.70; km_max_plano 27.00; degraus_y_plano 10; degraus_x_plano 4 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N1 | padrao | velha | km_p99_plano 21.60; km_max_plano 26.90; degraus_y_plano 9; degraus_x_plano 92 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N1 | liso | velha | km_p99_plano 21.60; km_max_plano 26.60; degraus_y_plano 6; degraus_x_plano 111 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N1 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N3 | padrao | velha | km_p99_plano 18.80; km_max_plano 24.70; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N3 | liso | velha | km_p99_plano 18.80; km_max_plano 26.60; degraus_y_plano 8 |
| Oil/Knife/Knife Grainy | P2000/W0.5/pr1/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N1 | padrao | velha | degraus_y_plano 2; degraus_x_plano 31 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N1 | padrao | pigmento | sem medida (alfa < 0,9) |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N1 | liso | velha | degraus_y_plano 1; degraus_x_plano 37 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N1 | liso | pigmento | furos 87.94 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N3 | padrao | velha | km_p99_plano 33.80; km_max_plano 36.20; degraus_y_plano 13; degraus_x_plano 78 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N3 | liso | velha | km_p99_plano 34.70; km_max_plano 36.40; furos 76.20; degraus_y_plano 15; degraus_x_plano 123 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.2/N3 | liso | pigmento | furos 22.16 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N1 | padrao | velha | manchas_azul_plano 3.56; km_p99_plano 31.70; km_max_plano 41.90; degraus_y_plano 12; degraus_x_plano 81 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N1 | liso | velha | km_p99_plano 33.80; km_max_plano 40.50; degraus_y_plano 11; degraus_x_plano 140 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N1 | liso | pigmento | furos 13.57 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N3 | padrao | velha | km_p99_plano 22.40; km_max_plano 38.40; degraus_y_plano 12; degraus_x_plano 55 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N3 | liso | velha | km_p99_plano 21.50; km_max_plano 32.90; degraus_y_plano 12; degraus_x_plano 39 |
| Oil/Knife/Knife Grainy | P2000/W1/pr0.6/N3 | liso | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N1 | padrao | velha | km_p99_plano 26.20; km_max_plano 43.00; degraus_y_plano 10; degraus_x_plano 89 |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N1 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N1 | liso | velha | km_p99_plano 25.10; km_max_plano 39.50; degraus_y_plano 13; degraus_x_plano 123 |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N1 | liso | pigmento | furos 0.16 |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N3 | padrao | velha | km_p99_plano 18.90; km_max_plano 28.00; degraus_y_plano 9; degraus_x_plano 52 |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N3 | padrao | pigmento | passa |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N3 | liso | velha | km_p99_plano 18.90; km_max_plano 27.10; degraus_y_plano 9; degraus_x_plano 49 |
| Oil/Knife/Knife Grainy | P2000/W1/pr1/N3 | liso | pigmento | passa |

### Velha × Pigmento: células que passam / total, por papel

| papel | velha | pigmento |
|---|---|---|
| padrao | 0 / 810 (290 sem medida) | 401 / 810 (339 sem medida) |
| liso | 0 / 810 (307 sem medida) | 347 / 810 (348 sem medida) |

### Células que reprovam na Pigmento

- `padrao` ExpressOil/Round/Express Oil `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` ExpressOil/Round/Express Oil `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` ExpressOil/Round/Express Oil `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` ExpressOil/Round/Express Oil `P2000/W1/pr0.6/N3`: furos 24.58
- `padrao` ExpressOil/Round/Express Oil `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` ExpressOil/Round/Express Oil `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` ExpressOil/Round/Express Oil `P600/W0.5/pr0.6/N3`: furos 17.06
- `padrao` ExpressOil/Round/Express Oil `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` ExpressOil/Round/Express Oil `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` ExpressOil/Round/Express Oil `P600/W1/pr0.6/N1`: degraus_y_plano 1
- `padrao` ExpressOil/Round/Express Oil `P600/W1/pr0.6/N3`: furos 48.67
- `padrao` Oil/Dabber/Dabber `P2000/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P2000/W0.5/pr0.6/N1`: furos 14.53; degraus_y_plano 1
- `padrao` Oil/Dabber/Dabber `P2000/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P2000/W0/pr0.6/N1`: furos 12.66
- `padrao` Oil/Dabber/Dabber `P2000/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P2000/W1/pr0.6/N1`: furos 24.87
- `padrao` Oil/Dabber/Dabber `P40/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P40/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P40/W0.5/pr0.6/N1`: furos 98.83
- `padrao` Oil/Dabber/Dabber `P40/W0.5/pr0.6/N3`: furos 12.92
- `padrao` Oil/Dabber/Dabber `P40/W0.5/pr1/N1`: furos 0.39
- `padrao` Oil/Dabber/Dabber `P40/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P40/W0/pr0.6/N1`: furos 12.66
- `padrao` Oil/Dabber/Dabber `P40/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P40/W1/pr0.6/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P40/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Dabber/Dabber `P600/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P600/W0.5/pr0.6/N1`: furos 22.55
- `padrao` Oil/Dabber/Dabber `P600/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P600/W0/pr0.6/N1`: furos 12.66
- `padrao` Oil/Dabber/Dabber `P600/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber `P600/W1/pr0.6/N1`: furos 53.78
- `padrao` Oil/Dabber/Dabber `P600/W1/pr0.6/N3`: furos 0.18
- `padrao` Oil/Dabber/Dabber 4 `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P2000/W0.5/pr0.6/N3`: furos 1.04
- `padrao` Oil/Dabber/Dabber 4 `P2000/W0.5/pr1/N3`: furos 0.65
- `padrao` Oil/Dabber/Dabber 4 `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P2000/W0/pr0.6/N3`: furos 0.96
- `padrao` Oil/Dabber/Dabber 4 `P2000/W0/pr1/N3`: furos 0.65
- `padrao` Oil/Dabber/Dabber 4 `P2000/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P2000/W1/pr0.6/N1`: furos 43.70
- `padrao` Oil/Dabber/Dabber 4 `P2000/W1/pr0.6/N3`: furos 0.99
- `padrao` Oil/Dabber/Dabber 4 `P2000/W1/pr1/N1`: furos 0.73
- `padrao` Oil/Dabber/Dabber 4 `P40/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P40/W0.5/pr0.6/N3`: furos 31.54
- `padrao` Oil/Dabber/Dabber 4 `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P40/W0/pr0.6/N3`: furos 0.96
- `padrao` Oil/Dabber/Dabber 4 `P40/W0/pr1/N3`: furos 0.65
- `padrao` Oil/Dabber/Dabber 4 `P40/W1/pr1/N1`: degraus_y_plano 2
- `padrao` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.6/N1`: furos 42.16
- `padrao` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.6/N3`: furos 0.89
- `padrao` Oil/Dabber/Dabber 4 `P600/W0.5/pr1/N1`: furos 0.68
- `padrao` Oil/Dabber/Dabber 4 `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P600/W0/pr0.6/N3`: furos 0.96
- `padrao` Oil/Dabber/Dabber 4 `P600/W0/pr1/N3`: furos 0.65
- `padrao` Oil/Dabber/Dabber 4 `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Dabber/Dabber 4 `P600/W1/pr0.6/N3`: furos 3.46
- `padrao` Oil/Flat/Filbert `P2000/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Filbert `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P2000/W0.5/pr0.6/N1`: furos 6.54
- `padrao` Oil/Flat/Filbert `P2000/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Filbert `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P2000/W0/pr0.6/N1`: furos 6.22
- `padrao` Oil/Flat/Filbert `P2000/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Filbert `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P2000/W1/pr0.6/N1`: furos 14.82; degraus_y_plano 2
- `padrao` Oil/Flat/Filbert `P40/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P40/W0.5/pr0.6/N1`: degraus_y_plano 1
- `padrao` Oil/Flat/Filbert `P40/W0.5/pr0.6/N3`: furos 14.32
- `padrao` Oil/Flat/Filbert `P40/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Filbert `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P40/W0/pr0.6/N1`: furos 6.22
- `padrao` Oil/Flat/Filbert `P40/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Flat/Filbert `P40/W1/pr1/N3`: degraus_y_plano 3
- `padrao` Oil/Flat/Filbert `P600/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Filbert `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P600/W0.5/pr0.6/N1`: furos 13.15
- `padrao` Oil/Flat/Filbert `P600/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Filbert `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P600/W0/pr0.6/N1`: furos 6.22
- `padrao` Oil/Flat/Filbert `P600/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Filbert `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert `P600/W1/pr0.6/N1`: furos 31.77; degraus_y_plano 5
- `padrao` Oil/Flat/Filbert `P600/W1/pr1/N1`: furos 0.21
- `padrao` Oil/Flat/Filbert Dry `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert Dry `P2000/W0.5/pr0.6/N1`: degraus_y_plano 2
- `padrao` Oil/Flat/Filbert Dry `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert Dry `P2000/W0/pr0.6/N1`: degraus_y_plano 2
- `padrao` Oil/Flat/Filbert Dry `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert Dry `P2000/W1/pr0.6/N3`: furos 2.06
- `padrao` Oil/Flat/Filbert Dry `P40/W0.5/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Flat/Filbert Dry `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert Dry `P40/W0/pr0.6/N1`: degraus_y_plano 2
- `padrao` Oil/Flat/Filbert Dry `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert Dry `P600/W0.5/pr0.6/N1`: degraus_y_plano 2
- `padrao` Oil/Flat/Filbert Dry `P600/W0.5/pr0.6/N3`: furos 1.35
- `padrao` Oil/Flat/Filbert Dry `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert Dry `P600/W0/pr0.6/N1`: degraus_y_plano 2
- `padrao` Oil/Flat/Filbert Dry `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Filbert Dry `P600/W1/pr0.6/N3`: furos 26.15
- `padrao` Oil/Flat/Flat Bristle `P2000/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P2000/W0.5/pr0.6/N1`: furos 6.95; degraus_y_plano 1
- `padrao` Oil/Flat/Flat Bristle `P2000/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P2000/W0/pr0.6/N1`: furos 5.55; degraus_y_plano 1
- `padrao` Oil/Flat/Flat Bristle `P2000/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P2000/W1/pr0.6/N1`: furos 11.46
- `padrao` Oil/Flat/Flat Bristle `P40/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P40/W0.5/pr0.6/N1`: degraus_y_plano 3
- `padrao` Oil/Flat/Flat Bristle `P40/W0.5/pr0.6/N3`: furos 1.48
- `padrao` Oil/Flat/Flat Bristle `P40/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P40/W0/pr0.6/N1`: furos 5.55; degraus_y_plano 1
- `padrao` Oil/Flat/Flat Bristle `P40/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Flat/Flat Bristle `P600/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P600/W0.5/pr0.6/N1`: furos 11.07
- `padrao` Oil/Flat/Flat Bristle `P600/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P600/W0/pr0.6/N1`: furos 5.55; degraus_y_plano 1
- `padrao` Oil/Flat/Flat Bristle `P600/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Flat Bristle `P600/W1/pr0.6/N1`: furos 18.83; degraus_y_plano 1
- `padrao` Oil/Flat/Thick Impasto `P2000/W0.5/pr0.2/N1`: furos 72.42; degraus_y_plano 1
- `padrao` Oil/Flat/Thick Impasto `P2000/W0/pr0.2/N1`: furos 63.70
- `padrao` Oil/Flat/Thick Impasto `P2000/W1/pr0.2/N1`: furos 99.61; degraus_y_plano 2
- `padrao` Oil/Flat/Thick Impasto `P2000/W1/pr0.2/N3`: furos 0.03
- `padrao` Oil/Flat/Thick Impasto `P40/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Thick Impasto `P40/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Thick Impasto `P40/W0/pr0.2/N1`: furos 63.70
- `padrao` Oil/Flat/Thick Impasto `P40/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Thick Impasto `P40/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Thick Impasto `P40/W1/pr0.6/N1`: furos 82.06
- `padrao` Oil/Flat/Thick Impasto `P600/W0.5/pr0.2/N1`: furos 98.57; degraus_y_plano 2
- `padrao` Oil/Flat/Thick Impasto `P600/W0/pr0.2/N1`: furos 63.70
- `padrao` Oil/Flat/Thick Impasto `P600/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Thick Impasto `P600/W1/pr0.2/N3`: furos 21.15
- `padrao` Oil/Flat/Tilted Shade `P2000/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P2000/W0.5/pr0.6/N1`: furos 3.46; degraus_y_plano 1
- `padrao` Oil/Flat/Tilted Shade `P2000/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P2000/W0/pr0.6/N1`: furos 2.37
- `padrao` Oil/Flat/Tilted Shade `P2000/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P2000/W1/pr0.6/N1`: furos 9.95
- `padrao` Oil/Flat/Tilted Shade `P40/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P40/W0.5/pr0.6/N1`: degraus_y_plano 4
- `padrao` Oil/Flat/Tilted Shade `P40/W0.5/pr0.6/N3`: furos 0.60
- `padrao` Oil/Flat/Tilted Shade `P40/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P40/W0/pr0.6/N1`: furos 2.37
- `padrao` Oil/Flat/Tilted Shade `P40/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P40/W1/pr0.6/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P40/W1/pr1/N1`: degraus_y_plano 2
- `padrao` Oil/Flat/Tilted Shade `P40/W1/pr1/N3`: furos 0.39
- `padrao` Oil/Flat/Tilted Shade `P600/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P600/W0.5/pr0.6/N1`: furos 9.09
- `padrao` Oil/Flat/Tilted Shade `P600/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P600/W0/pr0.6/N1`: furos 2.37
- `padrao` Oil/Flat/Tilted Shade `P600/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Flat/Tilted Shade `P600/W1/pr0.6/N1`: furos 18.18
- `padrao` Oil/Knife/Knife Dry `P2000/W0.5/pr0.2/N1`: furos 56.61
- `padrao` Oil/Knife/Knife Dry `P2000/W0.5/pr0.2/N3`: furos 0.62
- `padrao` Oil/Knife/Knife Dry `P2000/W0/pr0.2/N1`: furos 54.69
- `padrao` Oil/Knife/Knife Dry `P2000/W0/pr0.2/N3`: furos 0.47
- `padrao` Oil/Knife/Knife Dry `P2000/W1/pr0.2/N1`: furos 64.56
- `padrao` Oil/Knife/Knife Dry `P2000/W1/pr0.2/N3`: furos 2.81
- `padrao` Oil/Knife/Knife Dry `P40/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Dry `P40/W0.5/pr0.2/N3`: furos 70.03
- `padrao` Oil/Knife/Knife Dry `P40/W0.5/pr0.6/N1`: furos 2.06
- `padrao` Oil/Knife/Knife Dry `P40/W0/pr0.2/N1`: furos 54.69
- `padrao` Oil/Knife/Knife Dry `P40/W0/pr0.2/N3`: furos 0.47
- `padrao` Oil/Knife/Knife Dry `P40/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Dry `P40/W1/pr0.6/N3`: furos 0.81
- `padrao` Oil/Knife/Knife Dry `P40/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Dry `P600/W0.5/pr0.2/N1`: furos 62.89
- `padrao` Oil/Knife/Knife Dry `P600/W0.5/pr0.2/N3`: furos 2.21
- `padrao` Oil/Knife/Knife Dry `P600/W0/pr0.2/N1`: furos 54.69
- `padrao` Oil/Knife/Knife Dry `P600/W0/pr0.2/N3`: furos 0.47
- `padrao` Oil/Knife/Knife Dry `P600/W1/pr0.2/N1`: furos 85.68
- `padrao` Oil/Knife/Knife Dry `P600/W1/pr0.2/N3`: furos 9.38
- `padrao` Oil/Knife/Knife Dry `P600/W1/pr0.6/N1`: furos 0.03
- `padrao` Oil/Knife/Knife Grainy `P40/W0.5/pr0.6/N1`: degraus_y_plano 2
- `padrao` Oil/Knife/Knife Grainy `P40/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Grainy `P600/W0.5/pr0.6/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Grainy `P600/W1/pr0.6/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Oily `P2000/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P2000/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P2000/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P2000/W1/pr0.2/N3`: furos 0.76
- `padrao` Oil/Knife/Knife Oily `P40/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P40/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P40/W0.5/pr0.6/N1`: furos 52.92
- `padrao` Oil/Knife/Knife Oily `P40/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P40/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P40/W1/pr0.6/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Oily `P40/W1/pr0.6/N3`: furos 62.40
- `padrao` Oil/Knife/Knife Oily `P40/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Oily `P600/W0.5/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P600/W0.5/pr0.2/N3`: furos 0.21
- `padrao` Oil/Knife/Knife Oily `P600/W0.5/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Oily `P600/W0/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P600/W1/pr0.2/N1`: furos 100.00
- `padrao` Oil/Knife/Knife Oily `P600/W1/pr0.2/N3`: furos 51.48
- `padrao` Oil/Knife/Knife Oily `P600/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Smooth 3 `P40/W1/pr0.6/N3`: degraus_y_plano 6
- `padrao` Oil/Knife/Knife Textured `P2000/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Textured `P2000/W0.5/pr0.6/N3`: furos 78.15
- `padrao` Oil/Knife/Knife Textured `P2000/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Textured `P2000/W0/pr0.6/N3`: furos 73.41
- `padrao` Oil/Knife/Knife Textured `P2000/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Textured `P2000/W1/pr0.6/N3`: furos 89.79
- `padrao` Oil/Knife/Knife Textured `P40/W0.5/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Knife/Knife Textured `P40/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Textured `P40/W0/pr0.6/N3`: furos 73.41
- `padrao` Oil/Knife/Knife Textured `P40/W1/pr1/N3`: degraus_y_plano 5
- `padrao` Oil/Knife/Knife Textured `P600/W0.5/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Textured `P600/W0.5/pr0.6/N3`: furos 87.68
- `padrao` Oil/Knife/Knife Textured `P600/W0/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Textured `P600/W0/pr0.6/N3`: furos 73.41
- `padrao` Oil/Knife/Knife Textured `P600/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Knife/Knife Textured `P600/W1/pr0.6/N3`: furos 98.72
- `padrao` Oil/Knife/Knife Textured `P600/W1/pr1/N3`: furos 0.05
- `padrao` Oil/Metallic/Metallic Flat `P40/W0.5/pr0.2/N1`: furos 14.22
- `padrao` Oil/Metallic/Metallic Flat `P40/W0.5/pr0.6/N1`: furos 10.65
- `padrao` Oil/Metallic/Metallic Flat `P40/W1/pr0.2/N3`: furos 100.00
- `padrao` Oil/Metallic/Metallic Flat `P40/W1/pr0.6/N3`: furos 1.77
- `padrao` Oil/Metallic/Metallic Flat `P40/W1/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Metallic/Metallic Flat `P600/W0.5/pr1/N1`: degraus_y_plano 1
- `padrao` Oil/Metallic/Metallic Flat `P600/W1/pr0.2/N1`: furos 12.84
- `liso` ExpressOil/Round/Express Oil `P2000/W0.5/pr0.2/N3`: furos 100.00
- `liso` ExpressOil/Round/Express Oil `P2000/W0/pr0.2/N3`: furos 100.00
- `liso` ExpressOil/Round/Express Oil `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` ExpressOil/Round/Express Oil `P2000/W1/pr0.6/N3`: furos 24.58
- `liso` ExpressOil/Round/Express Oil `P40/W0/pr0.2/N3`: furos 100.00
- `liso` ExpressOil/Round/Express Oil `P600/W0.5/pr0.2/N3`: furos 100.00
- `liso` ExpressOil/Round/Express Oil `P600/W0.5/pr0.6/N3`: furos 17.06
- `liso` ExpressOil/Round/Express Oil `P600/W0/pr0.2/N3`: furos 100.00
- `liso` ExpressOil/Round/Express Oil `P600/W1/pr0.2/N3`: furos 100.00
- `liso` ExpressOil/Round/Express Oil `P600/W1/pr0.6/N1`: degraus_y_plano 1
- `liso` ExpressOil/Round/Express Oil `P600/W1/pr0.6/N3`: furos 48.67
- `liso` Oil/Dabber/Dabber `P2000/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P2000/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P2000/W0.5/pr0.6/N1`: furos 7.32
- `liso` Oil/Dabber/Dabber `P2000/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P2000/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P2000/W0/pr0.6/N1`: furos 5.47
- `liso` Oil/Dabber/Dabber `P2000/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P2000/W1/pr0.6/N1`: furos 14.61
- `liso` Oil/Dabber/Dabber `P40/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P40/W0.5/pr0.6/N1`: furos 94.22; degraus_y_plano 1
- `liso` Oil/Dabber/Dabber `P40/W0.5/pr0.6/N3`: furos 9.17
- `liso` Oil/Dabber/Dabber `P40/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P40/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P40/W0/pr0.6/N1`: furos 5.47
- `liso` Oil/Dabber/Dabber `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P40/W1/pr0.6/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P40/W1/pr1/N1`: degraus_y_plano 1
- `liso` Oil/Dabber/Dabber `P600/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P600/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P600/W0.5/pr0.6/N1`: furos 12.94
- `liso` Oil/Dabber/Dabber `P600/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P600/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P600/W0/pr0.6/N1`: furos 5.47
- `liso` Oil/Dabber/Dabber `P600/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber `P600/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber `P600/W1/pr0.6/N1`: furos 36.85; degraus_y_plano 2
- `liso` Oil/Dabber/Dabber `P600/W1/pr0.6/N3`: furos 0.03
- `liso` Oil/Dabber/Dabber 4 `P2000/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P2000/W0.5/pr0.2/N3`: furos 99.97
- `liso` Oil/Dabber/Dabber 4 `P2000/W0.5/pr0.6/N1`: furos 21.95; degraus_y_plano 1
- `liso` Oil/Dabber/Dabber 4 `P2000/W0.5/pr0.6/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P2000/W0.5/pr1/N1`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P2000/W0.5/pr1/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P2000/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P2000/W0/pr0.2/N3`: furos 99.97
- `liso` Oil/Dabber/Dabber 4 `P2000/W0/pr0.6/N1`: furos 19.84
- `liso` Oil/Dabber/Dabber 4 `P2000/W0/pr0.6/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P2000/W0/pr1/N1`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P2000/W0/pr1/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P2000/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P2000/W1/pr0.6/N1`: furos 27.71
- `liso` Oil/Dabber/Dabber 4 `P2000/W1/pr0.6/N3`: furos 0.08
- `liso` Oil/Dabber/Dabber 4 `P40/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P40/W0.5/pr0.6/N1`: furos 97.29
- `liso` Oil/Dabber/Dabber 4 `P40/W0.5/pr0.6/N3`: furos 18.46
- `liso` Oil/Dabber/Dabber 4 `P40/W0.5/pr1/N1`: furos 0.60
- `liso` Oil/Dabber/Dabber 4 `P40/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P40/W0/pr0.2/N3`: furos 99.97
- `liso` Oil/Dabber/Dabber 4 `P40/W0/pr0.6/N1`: furos 19.84
- `liso` Oil/Dabber/Dabber 4 `P40/W0/pr0.6/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P40/W0/pr1/N1`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P40/W0/pr1/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P40/W1/pr0.6/N3`: furos 99.95
- `liso` Oil/Dabber/Dabber 4 `P40/W1/pr1/N1`: degraus_y_plano 5
- `liso` Oil/Dabber/Dabber 4 `P40/W1/pr1/N3`: furos 0.44
- `liso` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.2/N3`: furos 99.97
- `liso` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.6/N1`: furos 26.69
- `liso` Oil/Dabber/Dabber 4 `P600/W0.5/pr0.6/N3`: furos 0.05
- `liso` Oil/Dabber/Dabber 4 `P600/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P600/W0/pr0.2/N3`: furos 99.97
- `liso` Oil/Dabber/Dabber 4 `P600/W0/pr0.6/N1`: furos 19.84
- `liso` Oil/Dabber/Dabber 4 `P600/W0/pr0.6/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P600/W0/pr1/N1`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P600/W0/pr1/N3`: furos 0.16
- `liso` Oil/Dabber/Dabber 4 `P600/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P600/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Dabber/Dabber 4 `P600/W1/pr0.6/N1`: furos 47.66
- `liso` Oil/Dabber/Dabber 4 `P600/W1/pr0.6/N3`: furos 0.96
- `liso` Oil/Flat/Filbert `P2000/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Filbert `P2000/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P2000/W0.5/pr0.6/N1`: furos 6.54
- `liso` Oil/Flat/Filbert `P2000/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Filbert `P2000/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P2000/W0/pr0.6/N1`: furos 6.22
- `liso` Oil/Flat/Filbert `P2000/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Filbert `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P2000/W1/pr0.6/N1`: furos 14.82; degraus_y_plano 2
- `liso` Oil/Flat/Filbert `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P40/W0.5/pr0.6/N1`: degraus_y_plano 1
- `liso` Oil/Flat/Filbert `P40/W0.5/pr0.6/N3`: furos 14.22
- `liso` Oil/Flat/Filbert `P40/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Filbert `P40/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P40/W0/pr0.6/N1`: furos 6.22
- `liso` Oil/Flat/Filbert `P40/W1/pr1/N1`: degraus_y_plano 1
- `liso` Oil/Flat/Filbert `P40/W1/pr1/N3`: degraus_y_plano 3
- `liso` Oil/Flat/Filbert `P600/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Filbert `P600/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P600/W0.5/pr0.6/N1`: furos 13.15
- `liso` Oil/Flat/Filbert `P600/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Filbert `P600/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P600/W0/pr0.6/N1`: furos 6.22
- `liso` Oil/Flat/Filbert `P600/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Filbert `P600/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert `P600/W1/pr0.6/N1`: furos 31.77; degraus_y_plano 5
- `liso` Oil/Flat/Filbert `P600/W1/pr1/N1`: furos 0.21
- `liso` Oil/Flat/Filbert Dry `P2000/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert Dry `P2000/W0.5/pr0.6/N1`: degraus_y_plano 2
- `liso` Oil/Flat/Filbert Dry `P2000/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert Dry `P2000/W0/pr0.6/N1`: degraus_y_plano 2
- `liso` Oil/Flat/Filbert Dry `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert Dry `P2000/W1/pr0.6/N3`: furos 2.06
- `liso` Oil/Flat/Filbert Dry `P40/W0.5/pr1/N1`: degraus_y_plano 1
- `liso` Oil/Flat/Filbert Dry `P40/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert Dry `P40/W0/pr0.6/N1`: degraus_y_plano 2
- `liso` Oil/Flat/Filbert Dry `P600/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert Dry `P600/W0.5/pr0.6/N1`: degraus_y_plano 1
- `liso` Oil/Flat/Filbert Dry `P600/W0.5/pr0.6/N3`: furos 1.35
- `liso` Oil/Flat/Filbert Dry `P600/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert Dry `P600/W0/pr0.6/N1`: degraus_y_plano 2
- `liso` Oil/Flat/Filbert Dry `P600/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Filbert Dry `P600/W1/pr0.6/N3`: furos 26.15
- `liso` Oil/Flat/Flat Bristle `P2000/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P2000/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P2000/W0.5/pr0.6/N1`: furos 6.95; degraus_y_plano 1
- `liso` Oil/Flat/Flat Bristle `P2000/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P2000/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P2000/W0/pr0.6/N1`: furos 5.55; degraus_y_plano 1
- `liso` Oil/Flat/Flat Bristle `P2000/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P2000/W1/pr0.6/N1`: furos 11.46
- `liso` Oil/Flat/Flat Bristle `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P40/W0.5/pr0.6/N1`: degraus_y_plano 3
- `liso` Oil/Flat/Flat Bristle `P40/W0.5/pr0.6/N3`: furos 1.48
- `liso` Oil/Flat/Flat Bristle `P40/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P40/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P40/W0/pr0.6/N1`: furos 5.55; degraus_y_plano 1
- `liso` Oil/Flat/Flat Bristle `P40/W1/pr1/N1`: degraus_y_plano 3
- `liso` Oil/Flat/Flat Bristle `P600/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P600/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P600/W0.5/pr0.6/N1`: furos 11.07
- `liso` Oil/Flat/Flat Bristle `P600/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P600/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P600/W0/pr0.6/N1`: furos 5.55; degraus_y_plano 1
- `liso` Oil/Flat/Flat Bristle `P600/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P600/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Flat Bristle `P600/W1/pr0.6/N1`: furos 18.83; degraus_y_plano 1
- `liso` Oil/Flat/Thick Impasto `P2000/W0.5/pr0.2/N1`: furos 72.42; degraus_y_plano 1
- `liso` Oil/Flat/Thick Impasto `P2000/W0/pr0.2/N1`: furos 63.70
- `liso` Oil/Flat/Thick Impasto `P2000/W1/pr0.2/N1`: furos 99.61; degraus_y_plano 2
- `liso` Oil/Flat/Thick Impasto `P2000/W1/pr0.2/N3`: furos 0.03
- `liso` Oil/Flat/Thick Impasto `P40/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Thick Impasto `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Thick Impasto `P40/W0/pr0.2/N1`: furos 63.70
- `liso` Oil/Flat/Thick Impasto `P40/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Thick Impasto `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Thick Impasto `P40/W1/pr0.6/N1`: furos 83.15
- `liso` Oil/Flat/Thick Impasto `P600/W0.5/pr0.2/N1`: furos 98.57; degraus_y_plano 2
- `liso` Oil/Flat/Thick Impasto `P600/W0/pr0.2/N1`: furos 63.70
- `liso` Oil/Flat/Thick Impasto `P600/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Thick Impasto `P600/W1/pr0.2/N3`: furos 21.15
- `liso` Oil/Flat/Tilted Shade `P2000/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P2000/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P2000/W0.5/pr0.6/N1`: furos 3.46; degraus_y_plano 1
- `liso` Oil/Flat/Tilted Shade `P2000/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P2000/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P2000/W0/pr0.6/N1`: furos 2.37
- `liso` Oil/Flat/Tilted Shade `P2000/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P2000/W1/pr0.6/N1`: furos 9.95
- `liso` Oil/Flat/Tilted Shade `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P40/W0.5/pr0.6/N1`: degraus_y_plano 4
- `liso` Oil/Flat/Tilted Shade `P40/W0.5/pr0.6/N3`: furos 0.60
- `liso` Oil/Flat/Tilted Shade `P40/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P40/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P40/W0/pr0.6/N1`: furos 2.37
- `liso` Oil/Flat/Tilted Shade `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P40/W1/pr0.6/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P40/W1/pr1/N1`: degraus_y_plano 3
- `liso` Oil/Flat/Tilted Shade `P40/W1/pr1/N3`: furos 0.31
- `liso` Oil/Flat/Tilted Shade `P600/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P600/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P600/W0.5/pr0.6/N1`: furos 9.09
- `liso` Oil/Flat/Tilted Shade `P600/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P600/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P600/W0/pr0.6/N1`: furos 2.37
- `liso` Oil/Flat/Tilted Shade `P600/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P600/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Flat/Tilted Shade `P600/W1/pr0.6/N1`: furos 18.18
- `liso` Oil/Knife/Knife Dry `P2000/W0.5/pr0.2/N1`: furos 42.63
- `liso` Oil/Knife/Knife Dry `P2000/W0.5/pr0.2/N3`: furos 0.13
- `liso` Oil/Knife/Knife Dry `P2000/W0.5/pr0.6/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0.5/pr0.6/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0.5/pr1/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0.5/pr1/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0/pr0.2/N1`: furos 40.76
- `liso` Oil/Knife/Knife Dry `P2000/W0/pr0.2/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0/pr0.6/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0/pr0.6/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0/pr1/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W0/pr1/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P2000/W1/pr0.2/N1`: furos 51.12
- `liso` Oil/Knife/Knife Dry `P2000/W1/pr0.2/N3`: furos 1.02
- `liso` Oil/Knife/Knife Dry `P40/W0.5/pr0.2/N1`: furos 98.91
- `liso` Oil/Knife/Knife Dry `P40/W0.5/pr0.2/N3`: furos 55.16
- `liso` Oil/Knife/Knife Dry `P40/W0.5/pr0.6/N1`: furos 0.21
- `liso` Oil/Knife/Knife Dry `P40/W0/pr0.2/N1`: furos 40.76
- `liso` Oil/Knife/Knife Dry `P40/W0/pr0.2/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P40/W0/pr0.6/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P40/W0/pr0.6/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P40/W0/pr1/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P40/W0/pr1/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Dry `P40/W1/pr0.6/N3`: furos 0.68
- `liso` Oil/Knife/Knife Dry `P600/W0.5/pr0.2/N1`: furos 50.47
- `liso` Oil/Knife/Knife Dry `P600/W0.5/pr0.2/N3`: furos 0.83
- `liso` Oil/Knife/Knife Dry `P600/W0/pr0.2/N1`: furos 40.76
- `liso` Oil/Knife/Knife Dry `P600/W0/pr0.2/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P600/W0/pr0.6/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P600/W0/pr0.6/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P600/W0/pr1/N1`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P600/W0/pr1/N3`: furos 0.05
- `liso` Oil/Knife/Knife Dry `P600/W1/pr0.2/N1`: furos 70.23
- `liso` Oil/Knife/Knife Dry `P600/W1/pr0.2/N3`: furos 4.74
- `liso` Oil/Knife/Knife Grainy `P2000/W0.5/pr0.2/N1`: degraus_y_plano 1
- `liso` Oil/Knife/Knife Grainy `P2000/W0/pr0.2/N1`: degraus_y_plano 1
- `liso` Oil/Knife/Knife Grainy `P2000/W1/pr0.2/N1`: furos 87.94
- `liso` Oil/Knife/Knife Grainy `P2000/W1/pr0.2/N3`: furos 22.16
- `liso` Oil/Knife/Knife Grainy `P2000/W1/pr0.6/N1`: furos 13.57
- `liso` Oil/Knife/Knife Grainy `P2000/W1/pr1/N1`: furos 0.16
- `liso` Oil/Knife/Knife Grainy `P40/W0.5/pr0.2/N3`: furos 97.60
- `liso` Oil/Knife/Knife Grainy `P40/W0.5/pr0.6/N1`: degraus_y_plano 2
- `liso` Oil/Knife/Knife Grainy `P40/W0.5/pr0.6/N3`: furos 3.75
- `liso` Oil/Knife/Knife Grainy `P40/W0/pr0.2/N1`: degraus_y_plano 1
- `liso` Oil/Knife/Knife Grainy `P600/W0.5/pr0.2/N1`: furos 90.13
- `liso` Oil/Knife/Knife Grainy `P600/W0.5/pr0.2/N3`: furos 20.91
- `liso` Oil/Knife/Knife Grainy `P600/W0.5/pr0.6/N1`: furos 12.58
- `liso` Oil/Knife/Knife Grainy `P600/W0.5/pr1/N1`: furos 0.10
- `liso` Oil/Knife/Knife Grainy `P600/W0/pr0.2/N1`: degraus_y_plano 1
- `liso` Oil/Knife/Knife Grainy `P600/W1/pr0.2/N1`: furos 93.44
- `liso` Oil/Knife/Knife Grainy `P600/W1/pr0.2/N3`: furos 36.67
- `liso` Oil/Knife/Knife Grainy `P600/W1/pr0.6/N1`: furos 23.44
- `liso` Oil/Knife/Knife Grainy `P600/W1/pr1/N1`: furos 0.96
- `liso` Oil/Knife/Knife Oily `P2000/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P2000/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P2000/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P2000/W1/pr0.2/N3`: furos 0.76
- `liso` Oil/Knife/Knife Oily `P40/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P40/W0.5/pr0.6/N1`: furos 52.92
- `liso` Oil/Knife/Knife Oily `P40/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P40/W1/pr0.6/N3`: furos 62.40
- `liso` Oil/Knife/Knife Oily `P40/W1/pr1/N1`: degraus_y_plano 2
- `liso` Oil/Knife/Knife Oily `P600/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P600/W0.5/pr0.2/N3`: furos 0.18
- `liso` Oil/Knife/Knife Oily `P600/W0.5/pr1/N1`: degraus_y_plano 1
- `liso` Oil/Knife/Knife Oily `P600/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P600/W1/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Oily `P600/W1/pr0.2/N3`: furos 51.48
- `liso` Oil/Knife/Knife Oily `P600/W1/pr1/N1`: degraus_y_plano 1
- `liso` Oil/Knife/Knife Smooth 3 `P2000/W1/pr0.2/N1`: furos 84.22
- `liso` Oil/Knife/Knife Smooth 3 `P2000/W1/pr0.2/N3`: furos 25.16
- `liso` Oil/Knife/Knife Smooth 3 `P2000/W1/pr0.6/N1`: furos 16.59
- `liso` Oil/Knife/Knife Smooth 3 `P2000/W1/pr0.6/N3`: furos 0.03
- `liso` Oil/Knife/Knife Smooth 3 `P40/W0.5/pr0.2/N3`: furos 94.84
- `liso` Oil/Knife/Knife Smooth 3 `P40/W0.5/pr0.6/N3`: furos 2.66
- `liso` Oil/Knife/Knife Smooth 3 `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Smooth 3 `P40/W1/pr0.6/N3`: furos 99.82
- `liso` Oil/Knife/Knife Smooth 3 `P40/W1/pr1/N3`: furos 0.03
- `liso` Oil/Knife/Knife Smooth 3 `P600/W0.5/pr0.2/N1`: furos 81.74
- `liso` Oil/Knife/Knife Smooth 3 `P600/W0.5/pr0.2/N3`: furos 24.87
- `liso` Oil/Knife/Knife Smooth 3 `P600/W0.5/pr0.6/N1`: furos 15.62
- `liso` Oil/Knife/Knife Smooth 3 `P600/W1/pr0.2/N1`: furos 95.99
- `liso` Oil/Knife/Knife Smooth 3 `P600/W1/pr0.2/N3`: furos 29.14
- `liso` Oil/Knife/Knife Smooth 3 `P600/W1/pr0.6/N1`: furos 26.54
- `liso` Oil/Knife/Knife Smooth 3 `P600/W1/pr0.6/N3`: furos 0.18
- `liso` Oil/Knife/Knife Smooth 3 `P600/W1/pr1/N1`: furos 0.42
- `liso` Oil/Knife/Knife Smooth 3 `P600/W1/pr1/N3`: furos 0.03
- `liso` Oil/Knife/Knife Stain `P40/W0.5/pr1/N3`: degraus_y_plano 3
- `liso` Oil/Knife/Knife Textured `P2000/W0.5/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P2000/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P2000/W0.5/pr0.6/N1`: furos 95.34
- `liso` Oil/Knife/Knife Textured `P2000/W0.5/pr0.6/N3`: furos 72.14
- `liso` Oil/Knife/Knife Textured `P2000/W0.5/pr1/N1`: furos 0.78
- `liso` Oil/Knife/Knife Textured `P2000/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P2000/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P2000/W0/pr0.6/N1`: furos 95.16
- `liso` Oil/Knife/Knife Textured `P2000/W0/pr0.6/N3`: furos 65.29
- `liso` Oil/Knife/Knife Textured `P2000/W0/pr1/N1`: furos 0.55
- `liso` Oil/Knife/Knife Textured `P2000/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P2000/W1/pr0.6/N3`: furos 87.47
- `liso` Oil/Knife/Knife Textured `P40/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P40/W0.5/pr0.6/N3`: furos 98.96
- `liso` Oil/Knife/Knife Textured `P40/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P40/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P40/W0/pr0.6/N1`: furos 95.16
- `liso` Oil/Knife/Knife Textured `P40/W0/pr0.6/N3`: furos 65.29
- `liso` Oil/Knife/Knife Textured `P40/W0/pr1/N1`: furos 0.55
- `liso` Oil/Knife/Knife Textured `P600/W0.5/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P600/W0.5/pr0.6/N3`: furos 86.85
- `liso` Oil/Knife/Knife Textured `P600/W0/pr0.2/N1`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P600/W0/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P600/W0/pr0.6/N1`: furos 95.16
- `liso` Oil/Knife/Knife Textured `P600/W0/pr0.6/N3`: furos 65.29
- `liso` Oil/Knife/Knife Textured `P600/W0/pr1/N1`: furos 0.55
- `liso` Oil/Knife/Knife Textured `P600/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Knife/Knife Textured `P600/W1/pr0.6/N3`: furos 95.89
- `liso` Oil/Metallic/Metallic Flat `P40/W0.5/pr0.2/N1`: furos 14.22
- `liso` Oil/Metallic/Metallic Flat `P40/W0.5/pr0.6/N1`: furos 10.60
- `liso` Oil/Metallic/Metallic Flat `P40/W1/pr0.2/N3`: furos 100.00
- `liso` Oil/Metallic/Metallic Flat `P40/W1/pr0.6/N3`: furos 1.90
- `liso` Oil/Metallic/Metallic Flat `P40/W1/pr1/N1`: degraus_y_plano 1
- `liso` Oil/Metallic/Metallic Flat `P600/W1/pr0.2/N1`: furos 12.84
